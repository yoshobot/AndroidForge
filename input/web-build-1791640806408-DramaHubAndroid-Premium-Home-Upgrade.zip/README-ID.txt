DramaHub Android — Full Features (AndroidForge)

Fitur pada source ini:
- Splash screen pembuka DramaHub.
- Login dan pendaftaran akun.
- Katalog drama dalam kartu poster 2 kolom.
- Pencarian, trending, terbaru, dan kategori (mengikuti endpoint backend yang dikonfigurasi).
- Halaman detail dan sinopsis drama.
- Pemutar video episode dengan kontrol dan tombol layar penuh.
- Episode 1–5 gratis; episode 6+ memerlukan langganan aktif.
- Pembelian/perpanjangan langganan QRIS AutoGoPay untuk paket 1, 3, 7, dan 30 hari.
- Tombol batalkan pembayaran, cek status pembayaran, zoom QRIS dengan tombol tutup.
- Profil, refresh status langganan berkala, riwayat tontonan, riwayat pembayaran.
- Daftar Saya / simpan drama untuk ditonton nanti.

Paket harga default yang ditampilkan: 1 hari Rp1.000, 3 hari Rp2.500, 7 hari Rp5.000, 30 hari Rp15.000.
Harga transaksi final tetap harus dikonfirmasi backend/server AutoGoPay; jangan menyimpan API key AutoGoPay atau secret QuickPlay di APK.

Build:
1. Upload ZIP ini sebagai source project di AndroidForge.
2. Jalankan Build APK.
3. Uji login, katalog, pemutaran episode, langganan, dan status pembayaran pada APK hasil build.

Catatan: source menggunakan backend DramaHub di https://zione.store/dramahub-api/. Backend tersebut harus aktif dan kompatibel dengan action yang dipanggil aplikasi. Source ZIP belum dapat diverifikasi dengan build AndroidForge dari lingkungan ini.


Pembaruan UI modern:
- Navigasi utama dipindahkan ke navbar bawah agar area katalog lebih lega.
- Profil dilengkapi status Premium, tombol refresh, akses riwayat tontonan/pembayaran, daftar simpanan, dan keluar akun.
- Dialog langganan menggunakan kartu paket modern, harga per paket, QRIS yang bisa diperbesar, cek pembayaran, dan batalkan transaksi.

Pembaruan UI modern:
- Ikon navigasi bawah menggunakan Material Icons, bukan karakter teks/emoji.
- Ikon launcher DramaHub khusus ditambahkan pada res/drawable/ic_dramahub.xml.
- Kartu dan navigasi menggunakan animasi perubahan ukuran/seleksi yang ringan.
- Dialog Premium menjelaskan episode gratis, episode premium, durasi akses, dan alur verifikasi QRIS.
- Harga paket yang ditampilkan: 1 hari Rp1.000, 3 hari Rp2.500, 7 hari Rp5.000, 30 hari Rp15.000.


FITUR VIDEO FEED (v1.2.0)
- Tab Video di navbar bawah membuka feed vertikal seperti aplikasi short-video.
- Setiap halaman menggunakan ID drama yang berbeda dari katalog trending; geser ke atas untuk drama berikutnya.
- Pemutaran episode 1 mengambil URL dari endpoint video backend berdasarkan ID drama, bukan mengulang URL drama sebelumnya.
- Tombol Suka tersimpan lokal per akun/perangkat dan tombol Simpan masuk ke Daftar Saya.
- Feed memerlukan katalog trending yang berhasil dimuat dan endpoint video backend yang mengembalikan URL stream valid.


Pembaruan Modern Auth / Episode 6 / Logo:
- Ikon launcher di-build akan mencoba mengambil gambar persis dari https://zione.store/icon.png. Jika URL tidak dapat dijangkau saat build, ikon fallback DramaHub di ZIP dipakai sehingga build tetap dapat berjalan.
- Logo di header dan popup juga menggunakan URL tersebut, dengan pengaturan logo dari backend tetap dapat menimpa URL default.
- Menekan episode 6+ saat belum login membuka popup login/daftar tanpa mengganti halaman drama/video. Setelah login, pengguna kembali ke halaman terakhir; jika langganan belum aktif, popup paket langganan akan ditampilkan.
- Halaman login/pendaftaran diperbarui dengan kartu modern, field membulat, tombol lihat/sembunyikan password, dan pesan validasi.

REVISI MONETISASI (UJI COBA)
- Semua episode dapat dipilih dari aplikasi; tidak ada lagi aturan episode 6 wajib Premium di sisi UI Android.
- Paket Premium yang tersedia tetap 1, 3, 7, dan 30 hari. Premium aktif melewati iklan.
- Pengguna gratis mendapat iklan interstitial uji coba setelah setiap 3 episode yang selesai diputar.
- Build menggunakan Google Mobile Ads SDK dan TEST app ID / TEST interstitial ad unit ID resmi Google. Iklan ini hanya untuk pengujian dan tidak menghasilkan pendapatan.
- Sebelum rilis, ganti APPLICATION_ID dan TEST_INTERSTITIAL_AD_UNIT_ID di AndroidManifest.xml dan MainActivity.kt dengan ID milik akun AdMob kamu.
- PENTING: APK ini hanya mengubah sisi Android. Jika endpoint video di server dramahub-api masih mengembalikan SUBSCRIPTION_REQUIRED untuk episode 6+, aturan itu juga harus dihapus di backend PHP agar semua episode benar-benar bisa diputar. File backend tidak termasuk dalam ZIP yang dikirim.
\n\nRevisi watermark dan hitungan pilihan episode (10 Okt 2026):\n- Watermark logo aplikasi dengan transparansi sedang ditambahkan pada tampilan player yang cocok.\n- Penghitung iklan dipindahkan ke pemilihan episode, termasuk episode berulang/tidak berurutan.\n- Premium aktif melewati iklan.\n- Gunakan ID uji AdMob saat pengujian.\n- Source belum dikompilasi/diuji APK dalam lingkungan ini; lakukan build AndroidForge dan periksa hasilnya.\n

Penyegaran beranda (10 Okt 2026): banner drama unggulan sinematik dan bagian Lanjutkan Menonton berdasarkan riwayat lokal ditambahkan di atas katalog. Source berbasis Fix9; tetap wajib build dan tes di AndroidForge, karena build APK belum dapat diverifikasi dari lingkungan ini.
