DramaHub — Catatan Update APK via AndroidForge

PENTING UNTUK UPDATE TANPA UNINSTALL
1. Tetap gunakan applicationId com.dramahub.app. Jangan mengubahnya untuk rilis update.
2. Semua APK rilis harus ditandatangani dengan keystore yang sama dengan APK yang sudah terpasang di perangkat. Gunakan workflow release-signed.yml AndroidForge dan secret keystore yang sama; jangan membuat keystore baru untuk setiap build.
3. app/build.gradle sekarang menetapkan versionCode otomatis berdasarkan waktu build (detik Unix), kecuali workflow menyediakan VERSION_CODE. Ini membuat versi build berikutnya biasanya lebih tinggi daripada versi sebelumnya. versionName tetap 1.3.1 kecuali workflow menyediakan VERSION_NAME.
4. ZIP ini adalah SOURCE CODE, bukan APK. Upload ZIP ini ke AndroidForge seperti alur yang sudah kamu pakai, lalu jalankan workflow rilis bertanda tangan.
5. Setelah build sukses, unduh APK release yang ditandatangani, lalu instal langsung di atas DramaHub lama. Jangan uninstall aplikasi lama terlebih dahulu.

Jika Android menampilkan “App not installed” atau konflik tanda tangan, jangan hapus aplikasi lama dulu. Itu biasanya berarti APK baru ditandatangani dengan kunci berbeda, applicationId berbeda, atau versi/arsitektur APK bermasalah. Periksa certificate APK lama dan baru serta pastikan workflow memakai keystore yang sama.

Catatan: build ini belum dijalankan di lingkungan lokal pada saat paket dibuat. Jalankan build AndroidForge dan uji pemasangan sebelum distribusi.
