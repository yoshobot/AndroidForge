DramaHub Android — Full Features (AndroidForge)

Fitur pada source ini:
- Splash screen pembuka DramaHub.
- Login dan pendaftaran akun.
- Katalog drama dalam kartu poster 2 kolom.
- Pencarian, trending, terbaru, dan kategori (mengikuti endpoint backend yang dikonfigurasi).
- Halaman detail dan sinopsis drama.
- Pemutar video episode dengan kontrol dan tombol layar penuh.
- Episode 1–5 gratis; episode 6+ memerlukan langganan aktif.
- Pembelian/perpanjangan langganan QRIS AutoGoPay untuk paket 1, 3, 7, dan 30 hari.
- Tombol batalkan pembayaran, cek status pembayaran, zoom QRIS dengan tombol tutup.
- Profil, refresh status langganan berkala, riwayat tontonan, riwayat pembayaran.
- Daftar Saya / simpan drama untuk ditonton nanti.

Paket harga default yang ditampilkan: 1 hari Rp1.000, 3 hari Rp2.500, 7 hari Rp5.000, 30 hari Rp15.000.
Harga transaksi final tetap harus dikonfirmasi backend/server AutoGoPay; jangan menyimpan API key AutoGoPay atau secret QuickPlay di APK.

Build:
1. Upload ZIP ini sebagai source project di AndroidForge.
2. Jalankan Build APK.
3. Uji login, katalog, pemutaran episode, langganan, dan status pembayaran pada APK hasil build.

Catatan: source menggunakan backend DramaHub di https://zione.store/dramahub-api/. Backend tersebut harus aktif dan kompatibel dengan action yang dipanggil aplikasi. Source ZIP belum dapat diverifikasi dengan build AndroidForge dari lingkungan ini.


Pembaruan UI modern:
- Navigasi utama dipindahkan ke navbar bawah agar area katalog lebih lega.
- Profil dilengkapi status Premium, tombol refresh, akses riwayat tontonan/pembayaran, daftar simpanan, dan keluar akun.
- Dialog langganan menggunakan kartu paket modern, harga per paket, QRIS yang bisa diperbesar, cek pembayaran, dan batalkan transaksi.

Pembaruan UI modern:
- Ikon navigasi bawah menggunakan Material Icons, bukan karakter teks/emoji.
- Ikon launcher DramaHub khusus ditambahkan pada res/drawable/ic_dramahub.xml.
- Kartu dan navigasi menggunakan animasi perubahan ukuran/seleksi yang ringan.
- Dialog Premium menjelaskan episode gratis, episode premium, durasi akses, dan alur verifikasi QRIS.
- Harga paket yang ditampilkan: 1 hari Rp1.000, 3 hari Rp2.500, 7 hari Rp5.000, 30 hari Rp15.000.
