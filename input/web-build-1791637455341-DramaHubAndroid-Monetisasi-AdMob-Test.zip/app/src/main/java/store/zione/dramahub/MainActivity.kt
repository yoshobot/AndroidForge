package store.zione.dramahub

import android.content.Context
import android.os.Bundle
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.FullScreenContentCallback
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.platform.LocalContext
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

private const val API_BASE = "https://zione.store/dramahub-api/"
private const val DEFAULT_LOGO_URL = "https://zione.store/icon.png"
private const val TEST_INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-3940256099942544/1033173712"
private val Bg = Color(0xFF080D19)
private val Panel = Color(0xFF111B2D)
private val Panel2 = Color(0xFF18263D)
private val Blue = Color(0xFF42A5F5)
private val Muted = Color(0xFF9AA9C3)
private val White = Color(0xFFF4F7FF)

data class Drama(val id:String, val title:String, val cover:String="", val synopsis:String="", val status:String="", val author:String="", val episodes:String="")
data class DramaCategory(val id:String, val name:String)
data class WatchEntry(val id:String, val title:String, val cover:String, val episode:Int, val time:Long)
data class PaymentEntry(val order:String, val amount:Int, val status:String, val days:Int, val created:String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MobileAds.initialize(this)
        window.statusBarColor = android.graphics.Color.rgb(8,13,25)
        window.navigationBarColor = android.graphics.Color.rgb(8,13,25)
        if (android.os.Build.VERSION.SDK_INT >= 29) { window.isNavigationBarContrastEnforced = false; window.isStatusBarContrastEnforced = false }
        setContent { DramaHubApp(this) }
    }
}

@Composable
fun DramaHubApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("dramahub", Context.MODE_PRIVATE) }
    var token by remember { mutableStateOf(prefs.getString("session_token", "") ?: "") }
    var screen by remember { mutableStateOf("splash") }
    val screenHistory = remember { mutableStateListOf<String>() }
    var returnScreenAfterAuth by remember { mutableStateOf("home") }
    var pendingEpisode by remember { mutableIntStateOf(0) }
    var resumePlaybackEpisode by remember { mutableIntStateOf(0) }
    var showExitConfirm by remember { mutableStateOf(false) }
    var appLogoUrl by remember { mutableStateOf(DEFAULT_LOGO_URL) }
    fun navigate(to: String) {
        if (screen != to) { screenHistory.add(screen); screen = to }
    }
    fun backToPrevious(): Boolean {
        if (screenHistory.isNotEmpty()) { screen = screenHistory.removeAt(screenHistory.lastIndex); return true }
        if (screen != "home") { screen = "home"; return true }
        return false
    }
    var authMode by remember { mutableStateOf("login") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var query by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("Masuk untuk melanjutkan.") }
    var loading by remember { mutableStateOf(false) }
    var dramas by remember { mutableStateOf(listOf<Drama>()) }
    var categories by remember { mutableStateOf(listOf<DramaCategory>()) }
    var selected by remember { mutableStateOf<Drama?>(null) }
    var detailJson by remember { mutableStateOf<JSONObject?>(null) }
    var selectedEpisode by remember { mutableIntStateOf(0) }
    var videoUrl by remember { mutableStateOf("") }
    var videoLoading by remember { mutableStateOf(false) }
    var videoRendered by remember { mutableStateOf(false) }
    var videoError by remember { mutableStateOf("") }
    var subscriptionActive by remember { mutableStateOf(false) }
    var subscriptionExpiry by remember { mutableStateOf("") }
    var showSubscriptionPrompt by remember { mutableStateOf(false) }
    var showAuthPrompt by remember { mutableStateOf(false) }
    var passwordVisible by remember { mutableStateOf(false) }
    var showFullscreenPlayer by remember { mutableStateOf(false) }
    var paymentOrderId by remember { mutableStateOf("") }
    var paymentQrUrl by remember { mutableStateOf("") }
    var paymentCheckoutUrl by remember { mutableStateOf("") }
    var paymentAmount by remember { mutableIntStateOf(1000) }
    var paymentMessage by remember { mutableStateOf("") }
    var paymentLoading by remember { mutableStateOf(false) }
    var showQrZoom by remember { mutableStateOf(false) }
    var selectedPlanDays by remember { mutableIntStateOf(1) }
    var watchHistory by remember { mutableStateOf(loadWatchHistory(prefs.getString("watch_history", "[]") ?: "[]")) }
    var savedDramas by remember { mutableStateOf(loadWatchHistory(prefs.getString("saved_dramas", "[]") ?: "[]")) }
    var likedDramaIds by remember { mutableStateOf((prefs.getString("liked_drama_ids", "") ?: "").split("|").filter { it.isNotBlank() }.toSet()) }
    var paymentHistory by remember { mutableStateOf(listOf<PaymentEntry>()) }
    var accountLabel by remember { mutableStateOf("") }
    var section by remember { mutableStateOf("trending") }
    val scope = rememberCoroutineScope()
    var player by remember { mutableStateOf<ExoPlayer?>(null) }
    var interstitialAd by remember { mutableStateOf<InterstitialAd?>(null) }
    var completedEpisodeCount by remember { mutableIntStateOf(prefs.getInt("completed_episode_count", 0)) }

    fun loadTestInterstitialAd() {
        InterstitialAd.load(context, TEST_INTERSTITIAL_AD_UNIT_ID, AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) { interstitialAd = ad }
                override fun onAdFailedToLoad(error: LoadAdError) { interstitialAd = null }
            })
    }

    LaunchedEffect(Unit) { loadTestInterstitialAd() }

    fun stopPlayer() { player?.run { playWhenReady = false; pause(); release() }; player = null }

    // Jangan biarkan audio/video terus berjalan setelah pindah ke halaman lain.
    LaunchedEffect(screen) {
        if (screen != "reels" && screen != "detail") {
            stopPlayer()
            videoUrl = ""
            videoRendered = false
            videoLoading = false
        }
    }

    fun load(path: String, label: String) {
        loading = true
        message = "Memuat $label…"
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    val action = when {
                        path == "categories" -> "categories"
                        path.startsWith("search:") -> "search"
                        path.startsWith("detail:") -> "detail"
                        else -> "trending"
                    }
                    val params = linkedMapOf<String,String>()
                    when {
                        action == "search" -> params["q"] = path.substringAfter("search:")
                        action == "detail" -> params["id"] = path.substringAfter("detail:")
                    }
                    backendGet(action, params, token)
                }
                when {
                    path == "categories" -> {
                        val arr = getArray(result)
                        categories = (0 until arr.length()).mapNotNull { i ->
                            arr.optJSONObject(i)?.let { o ->
                                val id = o.optString("name", o.optString("slug", o.optString("id")))
                                DramaCategory(id, o.optString("display_name", o.optString("name", o.optString("slug", "Kategori"))))
                            }
                        }
                        if (screen != "categories") screenHistory.add(screen)
                        screen = "categories"
                        message = "${categories.size} kategori tersedia"
                    }
                    path.startsWith("detail:") -> {
                        val data = result.optJSONObject("data") ?: result
                        detailJson = normalizeDetail(data)
                        if (screen != "detail") screenHistory.add(screen)
                        screen = "detail"
                        selectedEpisode = 0
                        videoUrl = ""
                        videoError = ""
                        stopPlayer()
                        message = "Pilih episode untuk mulai menonton."
                    }
                    else -> {
                        val arr = getArray(result)
                        dramas = (0 until arr.length()).mapNotNull { i ->
                            arr.optJSONObject(i)?.let { o ->
                                val rawId = o.optString("id", o.optString("bookId", o.optString("drama_id")))
                                val finalId = if (rawId.isNotBlank() && !rawId.contains("~")) "freereels~$rawId" else rawId
                                Drama(
                                    finalId,
                                    o.optString("title", o.optString("name", o.optString("bookName", "Tanpa judul"))),
                                    o.optString("cover", o.optString("poster", o.optString("cover_url", o.optString("image")))),
                                    o.optString("synopsis", o.optString("description", o.optString("desc"))),
                                    o.optString("status"),
                                    o.optString("author"),
                                    o.optString("chapters", o.optString("total_episodes", o.optString("episode_count")))
                                )
                            }
                        }
                        screen = "home"
                        message = "$label · ${dramas.size} judul"
                    }
                }
            } catch (e: Exception) {
                val err = e.message ?: "Permintaan gagal"
                if (err.contains("AUTH_REQUIRED", true) || err.contains("Sesi tidak valid", true)) {
                    token = ""
                    prefs.edit().remove("session_token").apply()
                    returnScreenAfterAuth = screen
                    screen = "auth"
                } else if (err.contains("SUBSCRIPTION_REQUIRED", true) || err.contains("Langganan tidak aktif", true)) {
                    subscriptionActive = false
                    videoError = err
                }
                message = err
            } finally { loading = false }
        }
    }

    fun refreshSubscriptionOnly(showMessage: Boolean = true) {
        if (token.isBlank()) { screen = "auth"; return }
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) { backendGet("me", emptyMap(), token) }
                val user = result.optJSONObject("user")
                accountLabel = user?.optString("username", accountLabel.ifBlank { username }).orEmpty()
                subscriptionActive = result.optBoolean("active", false)
                subscriptionExpiry = result.optString("expires_at", "").takeUnless { it == "null" }.orEmpty()
                if (showMessage) message = if (subscriptionActive) "Langganan aktif · status baru saja diperbarui." else "Belum ada langganan aktif. Jika admin baru mengaktifkan, tekan Segarkan lagi."
            } catch (e: Exception) {
                if (showMessage) message = e.message ?: "Gagal memperbarui status langganan."
            }
        }
    }

    // Profil menyegarkan status dari server berkala supaya perubahan admin muncul tanpa login ulang.
    LaunchedEffect(section, token) {
        if (section == "profile" && token.isNotBlank()) {
            while (true) {
                refreshSubscriptionOnly(false)
                kotlinx.coroutines.delay(15000)
            }
        }
    }

    fun checkSubscriptionAndContinue() {
        if (token.isBlank()) { screen = "auth"; return }
        loading = true
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) { backendGet("me", emptyMap(), token) }
                val user = result.optJSONObject("user")
                accountLabel = user?.optString("username", username).orEmpty()
                subscriptionActive = result.optBoolean("active", false)
                subscriptionExpiry = result.optString("expires_at", "")
                // Semua episode tersedia; status langganan hanya mengatur penayangan iklan.
                screen = "home"
                load("trending", "Trending")
                message = if (subscriptionActive) "Selamat datang kembali. Premium aktif tanpa iklan." else "Selamat datang! Semua episode tersedia dengan iklan berkala."
            } catch (e: Exception) {
                token = ""
                prefs.edit().remove("session_token").apply()
                subscriptionActive = false
                screen = "home"
                message = "Sesi berakhir. Kamu tetap bisa menjelajahi katalog."
                load("trending", "Trending")
            } finally { loading = false }
        }
    }

    fun submitAuth(register: Boolean) {
        if (username.trim().length < 4 || password.length < 8) {
            message = "Username minimal 4 karakter dan password minimal 8 karakter."
            return
        }
        loading = true
        message = if (register) "Membuat akun…" else "Memeriksa akun…"
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    backendPost(if (register) "register" else "login",
                        JSONObject().put("username", username.trim()).put("password", password))
                }
                if (register) {
                    authMode = "login"
                    password = ""
                    message = "Pendaftaran berhasil. Login untuk menyimpan riwayat dan mengelola langganan."
                } else {
                    token = result.optString("token")
                    if (token.isBlank()) throw IllegalStateException("Server tidak mengembalikan token login.")
                    prefs.edit().putString("session_token", token).apply()
                    showAuthPrompt = false
                    val returnTo = returnScreenAfterAuth
                    screen = returnTo
                    val me = withContext(Dispatchers.IO) { backendGet("me", emptyMap(), token) }
                    val user = me.optJSONObject("user")
                    accountLabel = user?.optString("username", username).orEmpty()
                    subscriptionActive = me.optBoolean("active", false)
                    subscriptionExpiry = me.optString("expires_at", "").takeUnless { it == "null" }.orEmpty()
                    if (pendingEpisode > 0) {
                        val ep = pendingEpisode
                        pendingEpisode = 0
                        resumePlaybackEpisode = ep
                    } else if (returnTo == "profile") {
                        screen = "profile"
                    }
                }
            } catch (e: Exception) {
                message = e.message ?: "Login/pendaftaran gagal."
            } finally { loading = false }
        }
    }

    fun logout() {
        scope.launch { withContext(Dispatchers.IO) { runCatching { backendGet("logout", emptyMap(), token) } } }
        stopPlayer()
        token = ""
        prefs.edit().remove("session_token").apply()
        screen = "home"
        screenHistory.clear()
        authMode = "login"
        detailJson = null
        selected = null
        subscriptionActive = false
        subscriptionExpiry = ""
        message = "Kamu sudah keluar. Katalog tetap bisa dijelajahi."
        load("trending", "Trending")
    }

    fun playEpisode(number: Int) {
        if (number < 1 || number > 1000) return
        videoLoading = true
        videoRendered = false
        videoError = ""
        videoUrl = ""
        selectedEpisode = number
        val watched = WatchEntry(selected?.id ?: "", selected?.title ?: "Drama", selected?.cover ?: "", number, System.currentTimeMillis())
        watchHistory = (listOf(watched) + watchHistory.filterNot { it.id == watched.id && it.episode == watched.episode }).take(100)
        prefs.edit().putString("watch_history", watchHistoryToJson(watchHistory)).apply()
        stopPlayer()
        scope.launch {
            try {
                val id = selected?.id ?: throw IllegalStateException("ID drama tidak tersedia.")
                val response = withContext(Dispatchers.IO) {
                    backendGet("video", linkedMapOf("id" to id, "episode" to number.toString()), token)
                }
                val data = response.optJSONObject("data") ?: response.optJSONObject("episode") ?: response
                val found = collectVideoUrls(data)
                val url = found.firstOrNull { it.contains(".m3u8", true) }
                    ?: found.firstOrNull { it.contains(".mp4", true) }
                    ?: found.firstOrNull { it.contains(".mpd", true) }
                    ?: found.firstOrNull()
                if (url.isNullOrBlank()) throw IllegalStateException("Backend tidak menerima URL video dari QuickPlay untuk episode ini.")
                if (screen !in listOf("reels", "detail")) {
                    videoLoading = false
                    return@launch
                }
                videoUrl = url
                withContext(Dispatchers.Main) {
                    if (screen !in listOf("reels", "detail")) return@withContext
                    player = ExoPlayer.Builder(context).build().also { p ->
                        p.addListener(object : androidx.media3.common.Player.Listener {
                            override fun onRenderedFirstFrame() {
                                videoRendered = true
                                videoError = ""
                            }
                            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                                videoRendered = false
                                videoError = "Video gagal diputar. Coba episode lain atau periksa URL stream di server."
                            }
                            override fun onPlaybackStateChanged(playbackState: Int) {
                                if (playbackState == androidx.media3.common.Player.STATE_ENDED) {
                                    completedEpisodeCount += 1
                                    prefs.edit().putInt("completed_episode_count", completedEpisodeCount).apply()
                                    if (!subscriptionActive && completedEpisodeCount % 3 == 0) {
                                        val ad = interstitialAd
                                        if (ad != null) {
                                            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                                                override fun onAdDismissedFullScreenContent() {
                                                    interstitialAd = null
                                                    loadTestInterstitialAd()
                                                }
                                                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                                                    interstitialAd = null
                                                    loadTestInterstitialAd()
                                                }
                                            }
                                            ad.show(context as android.app.Activity)
                                            interstitialAd = null
                                        } else {
                                            loadTestInterstitialAd()
                                        }
                                    }
                                }
                            }
                        })
                        p.setMediaItem(MediaItem.fromUri(url))
                        p.volume = 1f
                        p.playWhenReady = true
                        p.prepare()
                    }
                }
            } catch (e: Exception) {
                videoError = e.message ?: "Video gagal dimuat."
            } finally { videoLoading = false }
        }
    }

    LaunchedEffect(resumePlaybackEpisode, token, subscriptionActive) {
        val ep = resumePlaybackEpisode
        if (ep > 0 && token.isNotBlank()) {
            resumePlaybackEpisode = 0
            playEpisode(ep)
        }
    }

    fun createPayment(days: Int = selectedPlanDays) {
        if (token.isBlank()) { screen = "auth"; return }
        paymentLoading = true
        paymentMessage = "Membuat QRIS AutoGoPay…"
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    backendPost("payment_create", JSONObject().put("days", days), token)
                }
                paymentOrderId = result.optString("order_id")
                paymentQrUrl = result.optString("qr_url")
                paymentCheckoutUrl = result.optString("checkout_url")
                paymentAmount = result.optInt("amount", 1000 * days)
                selectedPlanDays = result.optInt("subscription_days", days)
                paymentMessage = "QRIS siap. Selesaikan pembayaran sebelum kedaluwarsa."
            } catch (e: Exception) {
                paymentMessage = e.message ?: "Gagal membuat pembayaran."
            } finally { paymentLoading = false }
        }
    }

    fun checkPayment() {
        if (paymentOrderId.isBlank()) {
            paymentMessage = "Buat pembayaran terlebih dahulu."
            return
        }
        paymentLoading = true
        paymentMessage = "Memeriksa status pembayaran…"
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    backendGet("payment_status", mapOf("order_id" to paymentOrderId), token)
                }
                val status = result.optString("status").uppercase()
                if (result.optBoolean("active", false) || status in listOf("PAID", "SETTLEMENT", "SUCCESS")) {
                    subscriptionActive = true
                    subscriptionExpiry = result.optString("expires_at", subscriptionExpiry)
                    showSubscriptionPrompt = false
                    paymentMessage = "Pembayaran berhasil. Langganan sudah aktif."
                    message = paymentMessage
                    if (pendingEpisode > 0) {
                        val ep = pendingEpisode
                        pendingEpisode = 0
                        playEpisode(ep)
                    }
                } else {
                    paymentMessage = "Pembayaran belum terkonfirmasi. Jika sudah membayar, tunggu sebentar lalu periksa lagi."
                }
            } catch (e: Exception) {
                paymentMessage = e.message ?: "Gagal memeriksa pembayaran."
            } finally { paymentLoading = false }
        }
    }

    LaunchedEffect(Unit) {
        // Ambil logo dari pengaturan admin; katalog tetap bisa dibuka tanpa login.
        scope.launch {
            runCatching {
                val settings = withContext(Dispatchers.IO) { backendGet("app_settings", emptyMap(), "") }
                appLogoUrl = settings.optString("logo_url", "").takeUnless { it == "null" }.orEmpty().ifBlank { DEFAULT_LOGO_URL }
            }
        }
        kotlinx.coroutines.delay(900)
        if (token.isNotBlank()) {
            try { checkSubscriptionAndContinue() } catch (_: Exception) { load("trending", "Trending") }
        } else {
            screen = "home"
            load("trending", "Trending")
        }
    }
    DisposableEffect(Unit) { onDispose { stopPlayer() } }

    BackHandler(enabled = true) {
        when {
            showQrZoom -> showQrZoom = false
            showAuthPrompt -> { showAuthPrompt = false; pendingEpisode = 0 }
            showSubscriptionPrompt -> showSubscriptionPrompt = false
            screen == "auth" -> { screen = returnScreenAfterAuth }
            showExitConfirm -> showExitConfirm = false
            screen != "home" -> backToPrevious()
            else -> showExitConfirm = true
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Blue, background = Bg, surface = Panel, onBackground = White, onSurface = White)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                if (screen != "splash") Row(
                    Modifier.fillMaxWidth().background(Bg).padding(start = 18.dp, end = 12.dp, top = 10.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(Blue), contentAlignment = Alignment.Center) {
                            AsyncImage(model = appLogoUrl.ifBlank { DEFAULT_LOGO_URL }, contentDescription = "Logo DramaHub", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                        }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("DRAMAHUB", fontSize = 22.sp, fontWeight = FontWeight.Black, color = White, letterSpacing = 1.1.sp)
                            Text("Cerita seru, kapan saja", fontSize = 12.sp, color = Muted)
                        }
                    }
                    if (token.isNotBlank() && screen !in listOf("splash", "auth", "checking")) {
                        TextButton(onClick = { logout() }) { Text("Keluar", color = Blue) }
                    }
                }
                Box(Modifier.weight(1f).fillMaxWidth()) {
                when (screen) {
                    "splash" -> SplashScreen(appLogoUrl)
                    "auth" -> {
                        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp), contentPadding = PaddingValues(bottom = 26.dp)) {
                            item {
                                Spacer(Modifier.height(22.dp))
                                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        AsyncImage(model = appLogoUrl.ifBlank { DEFAULT_LOGO_URL }, contentDescription = "Logo DramaHub", contentScale = ContentScale.Fit, modifier = Modifier.size(76.dp).clip(RoundedCornerShape(24.dp)))
                                        Text(if (authMode == "login") "Selamat datang kembali" else "Gabung dengan DramaHub", color = White, fontSize = 27.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 16.dp))
                                        Text(if (authMode == "login") "Masuk dan lanjutkan drama favoritmu." else "Buat akun untuk menyimpan dan melanjutkan tontonan.", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 7.dp))
                                    }
                                }
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(26.dp), modifier = Modifier.fillMaxWidth().padding(top = 25.dp)) {
                                    Column(Modifier.padding(19.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                        Text(if (authMode == "login") "Masuk ke akun" else "Buat akun baru", color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                        OutlinedTextField(value = username, onValueChange = { username = it.filter { ch -> ch.isLetterOrDigit() || ch in "_.-" }.take(40) }, label = { Text("Username") }, supportingText = { Text("Minimal 4 karakter") }, singleLine = true, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth(), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Blue, unfocusedBorderColor = Color(0xFF34435A), focusedLabelColor = Blue, cursorColor = Blue))
                                        OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Password") }, supportingText = { Text("Minimal 8 karakter") }, singleLine = true, visualTransformation = if (passwordVisible) androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation(), trailingIcon = { TextButton(onClick = { passwordVisible = !passwordVisible }) { Text(if (passwordVisible) "Sembunyikan" else "Lihat", color = Blue) } }, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth(), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Blue, unfocusedBorderColor = Color(0xFF34435A), focusedLabelColor = Blue, cursorColor = Blue))
                                        Button(onClick = { submitAuth(authMode == "register") }, enabled = !loading, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)) {
                                            if (loading) CircularProgressIndicator(Modifier.size(19.dp), color = Bg, strokeWidth = 2.dp) else Text(if (authMode == "login") "Masuk" else "Daftar sekarang", fontWeight = FontWeight.Bold)
                                        }
                                        TextButton(onClick = { authMode = if (authMode == "login") "register" else "login"; message = "" }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                                            Text(if (authMode == "login") "Belum punya akun? Daftar" else "Sudah punya akun? Masuk", color = Blue, fontWeight = FontWeight.SemiBold)
                                        }
                                    }
                                }
                                Text(message, color = if (message.contains("gagal", true) || message.contains("salah", true)) Color(0xFFFF8B8B) else Muted, modifier = Modifier.padding(top = 14.dp), fontSize = 12.sp)
                                Text("Semua episode tersedia. Pengguna gratis melihat iklan berkala; Premium bebas iklan selama masa aktif.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp, modifier = Modifier.padding(top = 12.dp))
                            }
                        }
                    }
                    "checking" -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = Blue)
                            Text("Memeriksa akun dan langganan…", color = Muted, modifier = Modifier.padding(top = 14.dp))
                        }
                    }
                    "subscription" -> LazyColumn(Modifier.fillMaxSize().padding(20.dp)) {
                        item {
                            Spacer(Modifier.height(34.dp))
                            Text("DramaHub Premium", color = White, fontSize = 28.sp, fontWeight = FontWeight.Black)
                            Text("Akun ${accountLabel.ifBlank { username }} sudah masuk, tetapi belum memiliki langganan aktif.", color = Muted, modifier = Modifier.padding(top = 10.dp))
                            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().padding(top = 22.dp)) {
                                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text("Aktifkan akses DramaHub", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                    Text("Cara kerja DramaHub Premium", color = White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    SubscriptionInfoRow(Icons.Filled.CheckCircle, "Semua episode tersedia", "Pengguna gratis dapat menonton semua episode dengan iklan berkala.", Color(0xFF5DE0B0))
                                    SubscriptionInfoRow(Icons.Filled.LockOpen, "Premium bebas iklan", "Langganan aktif menghapus iklan selama masa langganan.", Blue)
                                    SubscriptionInfoRow(Icons.Filled.Schedule, "Masa aktif sesuai paket", "Akses berakhir otomatis setelah durasi paket habis. Perpanjang kapan saja.", Color(0xFFFFC36B))
                                    SubscriptionInfoRow(Icons.Filled.CheckCircle, "Pembayaran otomatis", "Bayar melalui QRIS AutoGoPay. Setelah pembayaran terverifikasi, tekan Periksa pembayaran bila status belum berubah.", Color(0xFF5DE0B0))
                                    Text("ID akun dapat dilihat di pesan pendaftaran/login yang diberikan backend atau panel admin.", color = Muted, fontSize = 12.sp)
                                    Button(onClick = { checkSubscriptionAndContinue() }, modifier = Modifier.fillMaxWidth()) { Text("Periksa langganan lagi") }
                                    OutlinedButton(onClick = { logout() }, modifier = Modifier.fillMaxWidth()) { Text("Keluar") }
                                }
                            }
                            Text(message, color = Muted, modifier = Modifier.padding(top = 14.dp))
                        }
                    }
                    "profile" -> LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
                        item {
                            Spacer(Modifier.height(10.dp))
                            Text("Profil", color = White, fontSize = 30.sp, fontWeight = FontWeight.Black)
                            Text("Kelola akun dan langganan DramaHub", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp, bottom = 16.dp))
                            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(Modifier.size(58.dp).clip(RoundedCornerShape(20.dp)).background(Panel2), contentAlignment = Alignment.Center) { Text("👤", fontSize = 28.sp) }
                                        Spacer(Modifier.width(13.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(accountLabel.ifBlank { username.ifBlank { "Pengguna DramaHub" } }, color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            Text("Akun DramaHub", color = Muted, fontSize = 12.sp)
                                        }
                                        Surface(color = if (subscriptionActive) Color(0xFF123E38) else Panel2, shape = RoundedCornerShape(50)) {
                                            Text(if (subscriptionActive) "AKTIF" else "GRATIS", color = if (subscriptionActive) Color(0xFF5DE0B0) else Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp))
                                        }
                                    }
                                    HorizontalDivider(color = Color(0xFF27354B))
                                    Text(if (subscriptionActive) "Premium aktif · bebas iklan" else "Semua episode bisa ditonton", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                    Text(if (subscriptionActive && subscriptionExpiry.isNotBlank() && subscriptionExpiry != "null") "Langganan berlaku sampai $subscriptionExpiry" else if (subscriptionActive) "Semua episode tanpa iklan." else "Tonton semua episode dengan iklan berkala atau berlangganan untuk menghapus iklan.", color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
                                    Button(onClick = { refreshSubscriptionOnly(true) }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp), enabled = !loading) {
                                        Text(if (loading) "Memperbarui…" else "↻  Segarkan status", fontWeight = FontWeight.Bold)
                                    }
                                    OutlinedButton(onClick = { if (token.isBlank()) { returnScreenAfterAuth = "profile"; screen = "auth" } else showSubscriptionPrompt = true }, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(16.dp)) { Text("💎  Kelola langganan", fontWeight = FontWeight.SemiBold) }
                                }
                            }
                            Text("AKTIVITAS", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, modifier = Modifier.padding(top = 22.dp, bottom = 8.dp))
                            ProfileAction("♥", "Video disukai", "Kumpulan drama yang kamu beri suka") { if (token.isBlank()) { returnScreenAfterAuth = "profile"; screen = "auth" } else navigate("liked") }
                            ProfileAction("▣", "Daftar Saya", "Drama yang disimpan untuk ditonton nanti") { if (token.isBlank()) { returnScreenAfterAuth = "profile"; screen = "auth" } else navigate("saved") }
                            ProfileAction("▶", "Riwayat tontonan", "Lanjutkan drama yang terakhir kamu tonton") { if (token.isBlank()) { returnScreenAfterAuth = "profile"; screen = "auth" } else navigate("history") }
                            ProfileAction("▤", "Riwayat pembayaran", "Lihat status dan detail transaksi langganan") {
                                if (token.isBlank()) { returnScreenAfterAuth = "profile"; screen = "auth" } else navigate("payment_history")
                                scope.launch {
                                    runCatching { withContext(Dispatchers.IO) { backendGet("payment_history", emptyMap(), token) } }
                                        .onSuccess { res ->
                                            val arr = res.optJSONArray("data") ?: JSONArray()
                                            paymentHistory = (0 until arr.length()).mapNotNull { i ->
                                                arr.optJSONObject(i)?.let { o -> PaymentEntry(o.optString("order_id"), o.optInt("amount"), o.optString("status"), o.optInt("subscription_days", 1), o.optString("created_at")) }
                                            }
                                        }
                                        .onFailure { message = it.message ?: "Gagal memuat riwayat pembayaran." }
                                }
                            }
                            ProfileAction("↻", "Perbarui data akun", "Segarkan status langganan dari server") { refreshSubscriptionOnly(true) }
                            ProfileAction("⇥", "Keluar akun", "Keluar dari perangkat ini", danger = true) { logout() }
                            Text("DramaHub · versi aplikasi", color = Muted, fontSize = 11.sp, modifier = Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 10.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        }
                    }
                    "saved" -> LazyColumn(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
                        item {
                            Spacer(Modifier.height(14.dp))
                            Text("Daftar Saya", color = White, fontSize = 28.sp, fontWeight = FontWeight.Black)
                            Text("Drama yang kamu simpan untuk ditonton nanti.", color = Muted, modifier = Modifier.padding(top = 6.dp, bottom = 10.dp))
                        }
                        items(savedDramas) { entry ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable {
                                selected = Drama(entry.id, entry.title, entry.cover)
                                load("detail:" + entry.id, "Detail")
                            }, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                                Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                    AsyncImage(model = entry.cover, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.size(width = 76.dp, height = 100.dp).clip(RoundedCornerShape(10.dp)))
                                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                        Text(entry.title, color = White, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                        Text("Tersimpan · ketuk untuk membuka", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                                    }
                                    TextButton(onClick = {
                                        savedDramas = savedDramas.filterNot { it.id == entry.id }
                                        prefs.edit().putString("saved_dramas", watchHistoryToJson(savedDramas)).apply()
                                    }) { Text("Hapus", color = Color(0xFFFF8B8B)) }
                                }
                            }
                        }
                        if (savedDramas.isEmpty()) item {
                            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) {
                                Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("♡", fontSize = 42.sp, color = Blue)
                                    Text("Belum ada drama tersimpan", color = White, fontWeight = FontWeight.Bold)
                                    Text("Buka detail drama lalu tekan Simpan ke Daftar Saya.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                                }
                            }
                        }
                    }
                    "liked" -> {
                        val likedItems = (dramas.map { WatchEntry(it.id, it.title, it.cover, 0, 0L) } + watchHistory)
                            .distinctBy { it.id }.filter { likedDramaIds.contains(it.id) }
                        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
                            item {
                                Spacer(Modifier.height(14.dp))
                                Text("Video disukai", color = White, fontSize = 27.sp, fontWeight = FontWeight.Black)
                                Text("Drama yang kamu tandai dengan tombol suka.", color = Muted, modifier = Modifier.padding(top = 5.dp, bottom = 12.dp))
                            }
                            if (likedItems.isEmpty()) item {
                                EmptyProfileState("♡", "Belum ada video disukai", "Buka menu Video, lalu tekan ikon hati pada drama yang kamu suka.")
                            }
                            items(likedItems) { entry ->
                                Card(Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable {
                                    selected = Drama(entry.id, entry.title, entry.cover)
                                    load("detail:" + entry.id, "Detail")
                                }, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(17.dp)) {
                                    Row(Modifier.padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
                                        AsyncImage(model = entry.cover, contentDescription = entry.title, contentScale = ContentScale.Crop, modifier = Modifier.size(78.dp, 100.dp).clip(RoundedCornerShape(11.dp)))
                                        Column(Modifier.weight(1f).padding(start = 12.dp)) {
                                            Text(entry.title, color = White, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                            Text("Disukai ♥", color = Color(0xFFFF6B88), fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp))
                                            Text("Buka drama ›", color = Blue, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                                        }
                                        IconButton(onClick = {
                                            likedDramaIds = likedDramaIds - entry.id
                                            prefs.edit().putString("liked_drama_ids", likedDramaIds.joinToString("|")).apply()
                                        }) { Icon(Icons.Filled.Favorite, contentDescription = "Hapus suka", tint = Color(0xFFFF6B88)) }
                                    }
                                }
                            }
                        }
                    }
                    "payment_history" -> LazyColumn(Modifier.fillMaxSize().padding(horizontal = 14.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
                        item {
                            Spacer(Modifier.height(14.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("Riwayat pembayaran", color = White, fontSize = 27.sp, fontWeight = FontWeight.Black)
                                    Text("Status transaksi paket Premium kamu.", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp, bottom = 12.dp))
                                }
                                IconButton(onClick = {
                                    scope.launch {
                                        runCatching { withContext(Dispatchers.IO) { backendGet("payment_history", emptyMap(), token) } }
                                            .onSuccess { res ->
                                                val arr = res.optJSONArray("data") ?: JSONArray()
                                                paymentHistory = (0 until arr.length()).mapNotNull { i -> arr.optJSONObject(i)?.let { o -> PaymentEntry(o.optString("order_id"), o.optInt("amount"), o.optString("status"), o.optInt("subscription_days", 1), o.optString("created_at")) } }
                                                message = "Riwayat pembayaran diperbarui."
                                            }.onFailure { message = it.message ?: "Gagal memperbarui riwayat." }
                                    }
                                }) { Icon(Icons.Filled.Refresh, contentDescription = "Segarkan", tint = Blue) }
                            }
                            if (paymentHistory.isEmpty()) {
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(Icons.Filled.ReceiptLong, contentDescription = null, tint = Blue, modifier = Modifier.size(38.dp))
                                        Text("Belum ada data transaksi", color = White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                                        Text("Tekan tombol segarkan untuk memuat transaksi dari server.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp))
                                    }
                                }
                            }
                        }
                        items(paymentHistory) { payment ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(17.dp)) {
                                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                    Text(payment.order.ifBlank { "Transaksi DramaHub" }, color = White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    Text("${payment.days} hari · Rp${String.format("%,d", payment.amount).replace(',', '.')}", color = Muted, fontSize = 13.sp)
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(payment.created.ifBlank { "Tanggal tidak tersedia" }, color = Muted, fontSize = 11.sp, modifier = Modifier.weight(1f))
                                        val paid = payment.status.equals("PAID", true) || payment.status.equals("SUCCESS", true)
                                        Surface(color = if (paid) Color(0xFF123E38) else Panel2, shape = RoundedCornerShape(9.dp)) {
                                            Text(payment.status.ifBlank { "UNKNOWN" }.uppercase(), color = if (paid) Color(0xFF62E6BD) else Muted, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp))
                                        }
                                    }
                                }
                            }
                        }
                        item { Text(message, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp)) }
                    }
                    "history" -> LazyColumn(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
                        item {
                            Spacer(Modifier.height(14.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Riwayat tontonan", color = White, fontSize = 26.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                                TextButton(onClick = { watchHistory = emptyList(); prefs.edit().remove("watch_history").apply() }) { Text("Hapus", color = Blue) }
                            }
                        }
                        if (watchHistory.isEmpty()) item { Text("Belum ada tontonan. Pilih drama dan mulai menonton untuk mengisi riwayat.", color = Muted, modifier = Modifier.padding(12.dp)) }
                        items(watchHistory) { entry ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable {
                                selected = Drama(entry.id, entry.title, entry.cover)
                                load("detail:" + entry.id, "Detail")
                            }, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(15.dp)) {
                                Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                    AsyncImage(model = entry.cover, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.size(width = 62.dp, height = 82.dp).clip(RoundedCornerShape(9.dp)))
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(entry.title, color = White, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                        Text("Episode ${entry.episode}", color = Blue, modifier = Modifier.padding(top = 5.dp))
                                        Text(java.text.SimpleDateFormat("dd MMM yyyy, HH:mm", java.util.Locale("id", "ID")).format(java.util.Date(entry.time)), color = Muted, fontSize = 11.sp)
                                    }
                                    Text("Lanjut ›", color = Blue, fontSize = 12.sp)
                                }
                            }
                        }
                        item { Text("Riwayat pembayaran", color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 20.dp, bottom = 8.dp)) }
                        if (paymentHistory.isEmpty()) item { Text("Belum ada transaksi pembayaran.", color = Muted, modifier = Modifier.padding(bottom = 20.dp)) }
                        items(paymentHistory) { payment ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(13.dp)) {
                                Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(payment.order, color = White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text("${payment.days} hari · Rp${"%,d".format(java.util.Locale("id", "ID"), payment.amount)}", color = Muted, fontSize = 12.sp)
                                        Text(payment.created, color = Muted, fontSize = 11.sp)
                                    }
                                    Text(payment.status, color = if (payment.status.equals("PAID", true)) Blue else Muted, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                    "reels" -> {
                        if (dramas.isEmpty()) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Belum ada video", color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                    Text("Muat katalog dulu dari Beranda.", color = Muted, modifier = Modifier.padding(8.dp))
                                    Button(onClick = { screen = "home"; load("trending", "Trending") }) { Text("Muat drama") }
                                }
                            }
                        } else {
                            val reelPager = rememberPagerState(pageCount = { dramas.size })
                            LaunchedEffect(reelPager.currentPage, screen, dramas.size) {
                                if (screen == "reels" && dramas.isNotEmpty()) {
                                    val drama = dramas[reelPager.currentPage.coerceIn(0, dramas.lastIndex)]
                                    if (selected?.id != drama.id || selectedEpisode != 1 || videoUrl.isBlank()) {
                                        selected = drama
                                        playEpisode(1)
                                    }
                                }
                            }
                            VerticalPager(state = reelPager, modifier = Modifier.fillMaxSize(), beyondViewportPageCount = 0) { page ->
                                val drama = dramas[page]
                                val isCurrent = page == reelPager.currentPage
                                val liked = likedDramaIds.contains(drama.id)
                                val isSaved = savedDramas.any { it.id == drama.id }
                                Box(Modifier.fillMaxSize().background(Color.Black)) {
                                    AsyncImage(
                                        model = drama.cover,
                                        contentDescription = drama.title,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                    if (isCurrent && player != null && videoUrl.isNotBlank()) {
                                        AndroidView(
                                            factory = { ctx ->
                                                PlayerView(ctx).apply {
                                                    useController = false
                                                    resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                                    keepScreenOn = true
                                                    setShutterBackgroundColor(android.graphics.Color.TRANSPARENT)
                                                }
                                            },
                                            update = { view ->
                                                view.useController = false
                                                view.player = player
                                            },
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    }
                                    Box(Modifier.fillMaxSize().background(Color(0x33000000)))
                                    if (isCurrent && videoLoading) {
                                        CircularProgressIndicator(color = Blue, modifier = Modifier.align(Alignment.Center))
                                    }
                                    if (isCurrent && videoError.isNotBlank()) {
                                        Column(
                                            modifier = Modifier.align(Alignment.Center).padding(28.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = White, modifier = Modifier.size(42.dp))
                                            Text(videoError, color = White, fontSize = 13.sp)
                                            OutlinedButton(onClick = { playEpisode(1) }) { Text("Coba lagi", color = White) }
                                        }
                                    }
                                    Box(Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color(0x55000000), Color.Transparent, Color(0xCC000000)))))
                                    Text("DRAMAHUB · VIDEO", color = White, fontWeight = FontWeight.Black, fontSize = 14.sp, modifier = Modifier.align(Alignment.TopStart).padding(18.dp))
                                    Column(Modifier.align(Alignment.BottomStart).fillMaxWidth(0.78f).padding(start = 18.dp, bottom = 22.dp, end = 10.dp)) {
                                        Text(drama.title, color = White, fontSize = 21.sp, fontWeight = FontWeight.Black, lineHeight = 27.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                                        Text("Episode 1 · ${drama.status.ifBlank { "Drama pendek" }}", color = Color(0xFFBFDFFF), fontSize = 12.sp, modifier = Modifier.padding(top = 7.dp))
                                        Text(drama.synopsis.ifBlank { "Lanjutkan cerita ini di DramaHub." }, color = White, fontSize = 12.sp, maxLines = 3, overflow = TextOverflow.Ellipsis, lineHeight = 17.sp, modifier = Modifier.padding(top = 6.dp))
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 12.dp)) {
                                            Button(onClick = { selected = drama; load("detail:" + drama.id, "Detail") }, colors = ButtonDefaults.buttonColors(containerColor = Blue), shape = RoundedCornerShape(22.dp)) { Text("Detail drama") }
                                            OutlinedButton(onClick = { if (isCurrent) { stopPlayer(); videoUrl = ""; playEpisode(1) } else { scope.launch { reelPager.animateScrollToPage(page) } } }, shape = RoundedCornerShape(22.dp)) { Text("↻ Putar ulang", color = White) }
                                        }
                                    }
                                    Column(Modifier.align(Alignment.CenterEnd).padding(end = 13.dp, bottom = 46.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(18.dp)) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable {
                                            likedDramaIds = if (liked) likedDramaIds - drama.id else likedDramaIds + drama.id
                                            prefs.edit().putString("liked_drama_ids", likedDramaIds.joinToString("|")).apply()
                                        }.padding(5.dp)) {
                                            Icon(Icons.Filled.Favorite, contentDescription = "Suka", tint = if (liked) Color(0xFFFF5577) else White, modifier = Modifier.size(31.dp))
                                            Text(if (liked) "Disukai" else "Suka", color = White, fontSize = 10.sp)
                                        }
                                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable {
                                            savedDramas = if (isSaved) savedDramas.filterNot { it.id == drama.id } else (listOf(WatchEntry(drama.id, drama.title, drama.cover, 0, System.currentTimeMillis())) + savedDramas).take(200)
                                            prefs.edit().putString("saved_dramas", watchHistoryToJson(savedDramas)).apply()
                                        }.padding(5.dp)) {
                                            Icon(Icons.Filled.Bookmark, contentDescription = "Simpan", tint = if (isSaved) Blue else White, modifier = Modifier.size(29.dp))
                                            Text(if (isSaved) "Tersimpan" else "Simpan", color = White, fontSize = 10.sp)
                                        }
                                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { selected = drama; load("detail:" + drama.id, "Detail") }.padding(5.dp)) {
                                            Icon(Icons.Filled.PlayArrow, contentDescription = "Episode", tint = White, modifier = Modifier.size(31.dp))
                                            Text("Episode", color = White, fontSize = 10.sp)
                                        }
                                    }
                                    Text("Geser ke atas untuk drama berikutnya ↑", color = White.copy(alpha = 0.85f), fontSize = 10.sp, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 5.dp))
                                }
                            }
                        }
                    }
                    "categories" -> LazyColumn(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
                        item { Text(message, color = Muted, modifier = Modifier.padding(8.dp)) }
                        items(categories) { c ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(15.dp)) {
                                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text("▦", fontSize = 22.sp, color = Blue); Spacer(Modifier.width(12.dp))
                                    Column { Text(c.name, color = White, fontWeight = FontWeight.SemiBold); Text("Kategori tersedia dari provider", color = Muted, fontSize = 12.sp) }
                                }
                            }
                        }
                    }
                    "detail" -> {
                        val d = detailJson
                        if (d == null) Text("Detail belum tersedia", color = Muted, modifier = Modifier.padding(20.dp))
                        else LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                            item {
                                Row(Modifier.padding(top = 6.dp, bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text("‹", fontSize = 32.sp, color = Blue, modifier = Modifier.clickable { stopPlayer(); screen = "home" }.padding(end = 12.dp))
                                    Text("Detail drama", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = White)
                                }
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(14.dp)) {
                                        Row(verticalAlignment = Alignment.Top) {
                                            AsyncImage(model = d.optString("cover", selected?.cover), contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.width(116.dp).height(160.dp).clip(RoundedCornerShape(13.dp)))
                                            Spacer(Modifier.width(13.dp))
                                            Column(Modifier.weight(1f)) {
                                                Text(d.optString("title", selected?.title ?: "Drama"), color = White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                                                Text(d.optString("status", "Drama pendek"), color = Blue, fontSize = 12.sp, modifier = Modifier.padding(top = 7.dp))
                                                Text("${d.optString("total_episodes", d.optString("chapters", "-"))} episode", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 7.dp))
                                                Text(d.optString("author", ""), color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp), maxLines = 2, overflow = TextOverflow.Ellipsis)
                                            }
                                        }
                                        Text("SINOPSIS", fontSize = 11.sp, color = Blue, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, modifier = Modifier.padding(top = 16.dp))
                                        Text(d.optString("synopsis", "Sinopsis belum tersedia."), color = Muted, fontSize = 13.sp, lineHeight = 20.sp, modifier = Modifier.padding(top = 5.dp))
                                    }
                                }
                                val currentDramaId = selected?.id ?: ""
                                val isSaved = savedDramas.any { it.id == currentDramaId }
                                OutlinedButton(onClick = {
                                    if (currentDramaId.isNotBlank()) {
                                        savedDramas = if (isSaved) savedDramas.filterNot { it.id == currentDramaId } else (listOf(WatchEntry(currentDramaId, d.optString("title", "Drama"), d.optString("cover", ""), 0, System.currentTimeMillis())) + savedDramas).take(200)
                                        prefs.edit().putString("saved_dramas", watchHistoryToJson(savedDramas)).apply()
                                    }
                                }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) { Text(if (isSaved) "♥ Hapus dari Daftar Saya" else "♡ Simpan ke Daftar Saya") }
                                Spacer(Modifier.height(14.dp))
                                if (videoUrl.isNotBlank() && player != null) {
                                    Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(16.dp)).background(Color.Black)) {
                                        AndroidView(factory = { ctx -> PlayerView(ctx).apply { useController = true } },
                                            update = { it.player = player }, modifier = Modifier.fillMaxSize())
                                        Surface(
                                            color = Color(0xCC101827),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.align(Alignment.TopEnd).padding(8.dp).clickable { showFullscreenPlayer = true }
                                        ) {
                                            Text("⛶  Layar penuh", color = White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp))
                                        }
                                    }
                                    Text("Episode $selectedEpisode", color = White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp, bottom = 8.dp))
                                } else if (videoLoading) {
                                    LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 12.dp))
                                    Text("Menyiapkan episode $selectedEpisode…", color = Muted, fontSize = 13.sp)
                                }
                                if (videoError.isNotBlank()) Text(videoError, color = Color(0xFFFF8B8B), fontSize = 13.sp, modifier = Modifier.padding(vertical = 8.dp))
                                Text("PILIH EPISODE", color = White, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 14.dp, bottom = 10.dp))
                            }
                            val countRaw = d.optInt("total_episodes", d.optInt("episode_count", d.optInt("chapters", 0)))
                            val count = if (countRaw > 0) countRaw else d.optJSONArray("chapters")?.length() ?: d.optJSONArray("episodes")?.length() ?: 0
                            if (count > 0) {
                                items((1..count.coerceAtMost(500)).toList().chunked(3)) { row ->
                                    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        row.forEach { ep ->
                                            Button(onClick = { playEpisode(ep) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = if (ep == selectedEpisode) Blue else Panel2, contentColor = White), shape = RoundedCornerShape(12.dp)) { Text("▶  $ep", fontSize = 13.sp) }
                                        }
                                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                                    }
                                }
                            } else item { Text("Jumlah episode tidak ditemukan dari data detail.", color = Muted, fontSize = 13.sp) }
                            item { Spacer(Modifier.height(24.dp)) }
                        }
                    }
                    else -> Column(Modifier.fillMaxSize()) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("Cari judul drama…") }, singleLine = true, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp))
                            Spacer(Modifier.width(8.dp))
                            Button(onClick = { if (query.isNotBlank()) { section = "search"; load("search:" + query, "Hasil pencarian") } }, shape = RoundedCornerShape(13.dp)) { Text("Cari") }
                        }
                        Text(message, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp))
                        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
                        LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.fillMaxSize().padding(horizontal = 10.dp), contentPadding = PaddingValues(bottom = 18.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(dramas) { drama ->
                                Card(Modifier.fillMaxWidth().animateContentSize().clickable {
                                    selected = drama
                                    load("detail:" + drama.id, "Detail")
                                }, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(15.dp)) {
                                    Column(Modifier.padding(8.dp)) {
                                        AsyncImage(model = drama.cover, contentDescription = drama.title, contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxWidth().height(205.dp).clip(RoundedCornerShape(11.dp)))
                                        Text(drama.title, color = White, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp))
                                        Text("${drama.status.ifBlank { "Popular" }} ${if (drama.episodes.isNotBlank()) "· ${drama.episodes} eps" else ""}", color = Blue, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 5.dp))
                                        Text(drama.synopsis.ifBlank { drama.author }.ifBlank { "Buka untuk melihat detail dan episode." }, color = Muted, fontSize = 11.sp, maxLines = 3, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp), lineHeight = 15.sp)
                                        Text("LIHAT DRAMA  ›", color = Blue, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp, bottom = 2.dp))
                                    }
                                }
                            }
                            if (!loading && dramas.isEmpty()) item {
                                Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("🎬", fontSize = 36.sp)
                                    Text("Belum ada drama", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = White, modifier = Modifier.padding(top = 8.dp))
                                    Text(message, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                                    Button(onClick = { load("trending", "Trending") }, modifier = Modifier.padding(top = 12.dp)) { Text("Muat ulang") }
                                }
                            }
                        }
                    }
                }
                }
                if (screen !in listOf("splash", "auth", "checking") && !showFullscreenPlayer) {
                    ModernBottomBar(
                        selected = when (screen) {
                            "reels" -> "reels"
                            "categories" -> "categories"
                            "profile", "saved", "history", "liked", "payment_history", "subscription" -> "profile"
                            else -> "home"
                        },
                        onHome = { navigate("home"); section = "trending"; load("trending", "Trending") },
                        onReels = { if (dramas.isEmpty()) load("trending", "Trending"); navigate("reels") },
                        onCategories = { navigate("categories"); load("categories", "Kategori") },
                        onProfile = { if (token.isBlank()) { returnScreenAfterAuth = "profile"; authMode = "login"; screen = "auth" } else navigate("profile") }
                    )
                }
            }
            if (showExitConfirm) {
                AlertDialog(
                    onDismissRequest = { showExitConfirm = false },
                    containerColor = Panel,
                    title = { Text("Keluar dari DramaHub?", color = White, fontWeight = FontWeight.Bold) },
                    text = { Text("Kamu sudah menonton hari ini?", color = Muted) },
                    confirmButton = {
                        TextButton(onClick = { showExitConfirm = false; stopPlayer(); (context as? ComponentActivity)?.finish() }) {
                            Text("Iya", color = Blue, fontWeight = FontWeight.Bold)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showExitConfirm = false }) {
                            Text("Lanjut nonton", color = Blue, fontWeight = FontWeight.Bold)
                        }
                    }
                )
            }
            if (showAuthPrompt) {
                Dialog(onDismissRequest = { showAuthPrompt = false; pendingEpisode = 0 }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).heightIn(max = 650.dp),
                        shape = RoundedCornerShape(28.dp),
                        colors = CardDefaults.cardColors(containerColor = Panel),
                        elevation = CardDefaults.cardElevation(defaultElevation = 18.dp)
                    ) {
                        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(22.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                AsyncImage(model = appLogoUrl.ifBlank { DEFAULT_LOGO_URL }, contentDescription = "Logo DramaHub", contentScale = ContentScale.Fit, modifier = Modifier.size(48.dp).clip(RoundedCornerShape(15.dp)))
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("Satu langkah lagi", color = White, fontSize = 22.sp, fontWeight = FontWeight.Black)
                                    Text("Login untuk lanjut ke episode $pendingEpisode", color = Muted, fontSize = 12.sp)
                                }
                                IconButton(onClick = { showAuthPrompt = false; pendingEpisode = 0 }) { Icon(Icons.Filled.Close, contentDescription = "Tutup", tint = Muted) }
                            }
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF102A42)), shape = RoundedCornerShape(18.dp)) {
                                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.LockOpen, contentDescription = null, tint = Blue, modifier = Modifier.size(28.dp))
                                    Spacer(Modifier.width(12.dp))
                                    Column {
                                        Text("Semua episode tersedia", color = White, fontWeight = FontWeight.Bold)
                                        Text("Login opsional untuk menyimpan riwayat. Langganan Premium menghapus iklan.", color = Color(0xFFB7C8DD), fontSize = 12.sp, lineHeight = 17.sp)
                                    }
                                }
                            }
                            Text(if (authMode == "login") "Masuk ke DramaHub" else "Buat akun DramaHub", color = White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                            OutlinedTextField(value = username, onValueChange = { username = it.filter { ch -> ch.isLetterOrDigit() || ch in "_.-" }.take(40) }, label = { Text("Username") }, singleLine = true, shape = RoundedCornerShape(15.dp), modifier = Modifier.fillMaxWidth(), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Blue, unfocusedBorderColor = Color(0xFF34435A), focusedLabelColor = Blue, cursorColor = Blue))
                            OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Password") }, singleLine = true, visualTransformation = if (passwordVisible) androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation(), trailingIcon = { TextButton(onClick = { passwordVisible = !passwordVisible }) { Text(if (passwordVisible) "Sembunyikan" else "Lihat", color = Blue) } }, shape = RoundedCornerShape(15.dp), modifier = Modifier.fillMaxWidth(), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Blue, unfocusedBorderColor = Color(0xFF34435A), focusedLabelColor = Blue, cursorColor = Blue))
                            if (message.isNotBlank() && message != "Masuk untuk melanjutkan.") Text(message, color = if (message.contains("gagal", true) || message.contains("salah", true)) Color(0xFFFF8B8B) else Muted, fontSize = 12.sp, lineHeight = 17.sp)
                            Button(onClick = { submitAuth(authMode == "register") }, enabled = !loading, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(15.dp)) {
                                if (loading) CircularProgressIndicator(Modifier.size(18.dp), color = Bg, strokeWidth = 2.dp) else Text(if (authMode == "login") "Masuk dan lanjutkan" else "Daftar akun", fontWeight = FontWeight.Bold)
                            }
                            TextButton(onClick = { authMode = if (authMode == "login") "register" else "login"; message = "" }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                                Text(if (authMode == "login") "Belum punya akun? Daftar" else "Sudah punya akun? Masuk", color = Blue, fontWeight = FontWeight.SemiBold)
                            }
                            OutlinedButton(onClick = { showAuthPrompt = false; pendingEpisode = 0 }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp)) { Text("Nanti saja", color = Muted) }
                        }
                    }
                }
            }
            if (showSubscriptionPrompt) {
                Dialog(onDismissRequest = { showSubscriptionPrompt = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp).heightIn(max = 680.dp),
                        shape = RoundedCornerShape(28.dp),
                        colors = CardDefaults.cardColors(containerColor = Panel),
                        elevation = CardDefaults.cardElevation(defaultElevation = 14.dp)
                    ) {
                        Column(Modifier.fillMaxWidth().padding(20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("DramaHub Premium", color = White, fontSize = 23.sp, fontWeight = FontWeight.Black)
                                    Text("Pilih durasi untuk menonton tanpa iklan", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 3.dp))
                                }
                                IconButton(onClick = { showSubscriptionPrompt = false }) { Icon(Icons.Filled.Close, contentDescription = "Tutup", tint = Muted) }
                            }
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF123047)), shape = RoundedCornerShape(18.dp)) {
                                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text("💎", fontSize = 28.sp)
                                    Spacer(Modifier.width(12.dp))
                                    Column {
                                        Text(if (subscriptionActive) "Premium kamu aktif" else "Semua episode tersedia gratis", color = White, fontWeight = FontWeight.Bold)
                                        Text(if (subscriptionActive && subscriptionExpiry.isNotBlank()) "Aktif sampai $subscriptionExpiry" else "Premium menghapus iklan selama masa langganan.", color = Color(0xFFB7C8DD), fontSize = 12.sp, lineHeight = 17.sp)
                                    }
                                }
                            }
                            Text("PILIH PAKET LANGGANAN", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                            Text("Tidak ada tagihan otomatis berulang. Kamu membeli paket sesuai durasi yang dipilih.", color = Muted, fontSize = 12.sp, lineHeight = 17.sp)
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(1, 3, 7, 30).forEach { days ->
                                    val price = planPrice(days)
                                    val chosen = selectedPlanDays == days
                                    Surface(
                                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).clickable {
                                            selectedPlanDays = days
                                            if (paymentOrderId.isNotBlank()) { paymentOrderId = ""; paymentQrUrl = ""; paymentCheckoutUrl = ""; paymentAmount = price; paymentMessage = "Paket berubah. Buat QR baru untuk paket ini." }
                                        },
                                        color = if (chosen) Blue.copy(alpha = 0.15f) else Panel2,
                                        shape = RoundedCornerShape(15.dp),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, if (chosen) Blue else Color(0xFF29374D))
                                    ) {
                                        Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Column(Modifier.weight(1f)) {
                                                Text(when(days) { 1 -> "Harian"; 3 -> "3 Hari"; 7 -> "Mingguan"; else -> "Bulanan" }, color = White, fontWeight = FontWeight.Bold)
                                                Text(when(days) { 1 -> "Cocok untuk coba Premium"; 3 -> "Akses selama tiga hari"; 7 -> "Akses selama satu minggu"; else -> "Pilihan hemat satu bulan" }, color = Muted, fontSize = 11.sp)
                                            }
                                            Text("Rp${"%,d".format(java.util.Locale("id", "ID"), price)}", color = if (chosen) Blue else White, fontWeight = FontWeight.Bold)
                                            Spacer(Modifier.width(8.dp))
                                            Text(if (chosen) "●" else "○", color = if (chosen) Blue else Muted)
                                        }
                                    }
                                }
                            }
                            if (paymentQrUrl.isNotBlank()) {
                                AsyncImage(model = paymentQrUrl, contentDescription = "Ketuk untuk memperbesar QRIS", contentScale = ContentScale.Fit,
                                    modifier = Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(16.dp)).background(Color.White).clickable { showQrZoom = true }.padding(7.dp))
                                Text("Ketuk QR untuk memperbesar", color = Blue, fontSize = 11.sp)
                                Text("ID transaksi: $paymentOrderId", color = Muted, fontSize = 11.sp)
                            }
                            if (paymentMessage.isNotBlank()) {
                                Text(paymentMessage, color = if (paymentMessage.contains("berhasil", true)) Color(0xFF5DE0B0) else Muted, fontSize = 12.sp, lineHeight = 17.sp)
                            }
                            Button(onClick = { createPayment(selectedPlanDays) }, enabled = !paymentLoading, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) {
                                if (paymentLoading) CircularProgressIndicator(Modifier.size(18.dp), color = Bg, strokeWidth = 2.dp)
                                else Text(if (paymentOrderId.isBlank()) "Beli paket sekarang" else "Buat QR baru", fontWeight = FontWeight.Bold)
                            }
                            OutlinedButton(onClick = { checkPayment() }, enabled = !paymentLoading && paymentOrderId.isNotBlank(), modifier = Modifier.fillMaxWidth().height(49.dp), shape = RoundedCornerShape(16.dp)) { Text("Periksa pembayaran") }
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedButton(onClick = {
                                    val orderToCancel = paymentOrderId
                                    if (orderToCancel.isNotBlank()) scope.launch { runCatching { withContext(Dispatchers.IO) { backendPost("payment_cancel", JSONObject().put("order_id", orderToCancel), token) } } }
                                    paymentOrderId = ""; paymentQrUrl = ""; paymentCheckoutUrl = ""; paymentAmount = planPrice(selectedPlanDays); paymentMessage = "Transaksi dibatalkan."; showSubscriptionPrompt = false
                                }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) { Text("Batalkan") }
                                TextButton(onClick = { showSubscriptionPrompt = false }, modifier = Modifier.weight(1f).height(48.dp)) { Text("Nanti", color = Muted) }
                            }
                        }
                    }
                }
            }
            if (showQrZoom && paymentQrUrl.isNotBlank()) {
                Dialog(onDismissRequest = { showQrZoom = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
                    Box(Modifier.fillMaxSize().background(Color(0xF5080D19)).clickable { showQrZoom = false }, contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth().padding(20.dp)) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text("QRIS AutoGoPay", color = White, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
                                TextButton(onClick = { showQrZoom = false }) { Icon(Icons.Filled.Close, contentDescription = null, tint = Blue); Spacer(Modifier.width(4.dp)); Text("Tutup", color = Blue) }
                            }
                            AsyncImage(model = paymentQrUrl, contentDescription = "QRIS diperbesar", contentScale = ContentScale.Fit,
                                modifier = Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(12.dp)).background(Color.White).padding(8.dp))
                            Text("Order: $paymentOrderId", color = Muted, modifier = Modifier.padding(top = 12.dp))
                            Button(onClick = { showQrZoom = false }, modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) { Text("Tutup QR") }
                        }
                    }
                }
            }
            if (showFullscreenPlayer && player != null) {
                Dialog(
                    onDismissRequest = { showFullscreenPlayer = false },
                    properties = DialogProperties(usePlatformDefaultWidth = false)
                ) {
                    Box(Modifier.fillMaxSize().background(Color.Black)) {
                        AndroidView(factory = { ctx -> PlayerView(ctx).apply { useController = true; resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT } },
                            update = { it.player = player }, modifier = Modifier.fillMaxSize())
                        Surface(
                            color = Color(0xCC101827),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.align(Alignment.TopEnd).padding(12.dp).clickable { showFullscreenPlayer = false }
                        ) {
                            Text("✕  Tutup", color = White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp))
                        }
                    }
                }
            }
        }
    }
}

private fun planPrice(days: Int): Int = when (days) { 1 -> 1000; 3 -> 2500; 7 -> 5000; 30 -> 15000; else -> 1000 * days }

@Composable
private fun SplashScreen(appLogoUrl: String = "") {
    Box(Modifier.fillMaxSize().background(Color(0xFF05070D)), contentAlignment = Alignment.Center) {
        Column(Modifier.fillMaxSize().padding(horizontal = 22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceBetween) {
            Spacer(Modifier.height(26.dp))
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    listOf(Color(0xFF18243B), Color(0xFF263A59), Color(0xFF15233A)).forEachIndexed { i, c ->
                        Box(Modifier.width(if (i == 1) 100.dp else 82.dp).height(if (i == 1) 178.dp else 148.dp).clip(RoundedCornerShape(14.dp)).background(c), contentAlignment = Alignment.Center) {
                            Text(listOf("▶", "DH", "✦")[i], color = if (i == 1) Blue else Color(0xFFB7C9E8), fontSize = if (i == 1) 28.sp else 24.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }
                Spacer(Modifier.height(28.dp))
                AsyncImage(model = appLogoUrl.ifBlank { DEFAULT_LOGO_URL }, contentDescription = "Logo DramaHub", contentScale = ContentScale.Fit, modifier = Modifier.size(76.dp).clip(RoundedCornerShape(20.dp)))
                Text("DRAMAHUB", color = White, fontSize = 31.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                Text("Cerita seru, kapan saja", color = Muted, fontSize = 14.sp, modifier = Modifier.padding(top = 7.dp))
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(bottom = 40.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("100% ", color = White, fontSize = 27.sp, fontWeight = FontWeight.Black)
                    Text("GRATIS", color = Color(0xFFFF5B55), fontSize = 27.sp, fontWeight = FontWeight.Black)
                }
                Text("Kapan Saja · Setiap Episode", color = White, fontSize = 17.sp, modifier = Modifier.padding(top = 7.dp))
                CircularProgressIndicator(color = Blue, strokeWidth = 2.dp, modifier = Modifier.padding(top = 22.dp).size(24.dp))
            }
        }
    }
}

@Composable
private fun EmptyProfileState(icon: String, title: String, description: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(icon, fontSize = 42.sp, color = Blue)
            Text(title, color = White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
            Text(description, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

@Composable
private fun ModernBottomBar(
    selected: String,
    onHome: () -> Unit,
    onReels: () -> Unit,
    onCategories: () -> Unit,
    onProfile: () -> Unit
) {
    Surface(color = Color(0xFF0C1423), shadowElevation = 18.dp, tonalElevation = 4.dp) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            BottomItem(Icons.Filled.Home, "Beranda", selected == "home") { onHome() }
            BottomItem(Icons.Filled.PlayArrow, "Video", selected == "reels") { onReels() }
            BottomItem(Icons.Filled.Category, "Kategori", selected == "categories") { onCategories() }
            BottomItem(Icons.Filled.Person, "Profil", selected == "profile") { onProfile() }
        }
    }
}

@Composable
private fun BottomItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    val scale by animateFloatAsState(if (selected) 1.06f else 1f, animationSpec = spring(dampingRatio = 0.62f, stiffness = 500f), label = "navScale")
    Column(Modifier.widthIn(min = 48.dp).clip(RoundedCornerShape(15.dp)).clickable(onClick = onClick).padding(horizontal = 5.dp, vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Box(Modifier.animateContentSize().clip(RoundedCornerShape(12.dp)).background(if (selected) Blue.copy(alpha = 0.20f) else Color.Transparent).padding(horizontal = if (selected) 13.dp else 11.dp, vertical = if (selected) 6.dp else 5.dp), contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = label, tint = if (selected) Blue else Muted, modifier = Modifier.size((19 * scale).dp))
        }
        Text(label, color = if (selected) Blue else Muted, fontSize = 9.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
    }
}

@Composable
private fun SubscriptionInfoRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, detail: String, tint: Color) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(Panel2.copy(alpha = 0.72f)).padding(12.dp), verticalAlignment = Alignment.Top) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.padding(top = 1.dp).size(21.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(title, color = White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(detail, color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
        }
    }
}

@Composable
private fun ProfileAction(icon: String, title: String, subtitle: String, danger: Boolean = false, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp).animateContentSize().clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(17.dp)) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(if (danger) Color(0xFF3A1D2A) else Panel2), contentAlignment = Alignment.Center) {
                Text(icon, color = if (danger) Color(0xFFFF8795) else Blue, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = if (danger) Color(0xFFFF8795) else White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text(subtitle, color = Muted, fontSize = 11.sp, lineHeight = 15.sp)
            }
            Text("›", color = Muted, fontSize = 24.sp)
        }
    }
}

@Composable
private fun NavChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(color = if (selected) Blue else Panel2, shape = RoundedCornerShape(12.dp), modifier = Modifier.clickable(onClick = onClick)) {
        Text(label, color = if (selected) Bg else White, fontWeight = FontWeight.SemiBold, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp))
    }
}

private fun loadWatchHistory(raw: String): List<WatchEntry> = runCatching {
    val arr = JSONArray(raw)
    (0 until arr.length()).mapNotNull { i -> arr.optJSONObject(i)?.let { o ->
        WatchEntry(o.optString("id"), o.optString("title", "Drama"), o.optString("cover"), o.optInt("episode"), o.optLong("time"))
    } }
}.getOrDefault(emptyList())

private fun watchHistoryToJson(items: List<WatchEntry>): String {
    val arr = JSONArray()
    items.forEach { e -> arr.put(JSONObject().put("id", e.id).put("title", e.title).put("cover", e.cover).put("episode", e.episode).put("time", e.time)) }
    return arr.toString()
}

private fun getArray(json: JSONObject): JSONArray {
    for (key in listOf("data", "items", "results", "categories")) json.optJSONArray(key)?.let { return it }
    json.optJSONObject("data")?.let { d -> for (key in listOf("data", "items", "results", "categories")) d.optJSONArray(key)?.let { return it } }
    return JSONArray()
}

private fun normalizeDetail(source: JSONObject): JSONObject {
    val out = JSONObject(source.toString())
    if (!out.has("title")) out.put("title", source.optString("name", source.optString("bookName", "Drama")))
    if (!out.has("cover")) out.put("cover", source.optString("poster", source.optString("cover_url", source.optString("image", ""))))
    if (!out.has("synopsis")) out.put("synopsis", source.optString("description", source.optString("desc", "")))
    if (!out.has("total_episodes")) out.put("total_episodes", source.optInt("episode_count", source.optInt("chapters", 0)))
    if (out.opt("total_episodes") is JSONObject || out.opt("total_episodes") is JSONArray) {
        val eps = out.optJSONArray("chapters") ?: out.optJSONArray("episodes")
        out.put("total_episodes", eps?.length() ?: 0)
    }
    return out
}

private fun collectVideoUrls(obj: Any?, out: MutableList<String> = mutableListOf()): List<String> {
    when (obj) {
        is JSONObject -> {
            val keys = obj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val v = obj.opt(k)
                if (v is String && v.startsWith("http", true) &&
                    (k.contains("video", true) || k.contains("stream", true) || k.contains("play", true) ||
                     k.contains("url", true) || k.contains("source", true) || k == "src" || k == "link" ||
                     v.contains(".m3u8", true) || v.contains(".mp4", true) || v.contains(".mpd", true))) {
                    if (!k.contains("subtitle", true) && !k.contains("poster", true) && !k.contains("image", true)) out.add(v)
                } else collectVideoUrls(v, out)
            }
        }
        is JSONArray -> for (i in 0 until obj.length()) collectVideoUrls(obj.opt(i), out)
    }
    return out.distinct()
}

private fun backendGet(action: String, params: Map<String, String>, token: String): JSONObject {
    val all = linkedMapOf("action" to action)
    all.putAll(params)
    val query = all.entries.joinToString("&") { (k, v) -> enc(k) + "=" + enc(v) }
    val headers = mutableMapOf<String, String>()
    if (token.isNotBlank()) headers["Authorization"] = "Bearer $token"
    return requestBackend(API_BASE + "?" + query, "GET", headers, null)
}

private fun backendPost(action: String, body: JSONObject, token: String = ""): JSONObject {
    val headers = mutableMapOf("Content-Type" to "application/json")
    if (token.isNotBlank()) headers["Authorization"] = "Bearer $token"
    return requestBackend(API_BASE + "?action=" + enc(action), "POST", headers, body.toString())
}

private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8").replace("+", "%20")

private fun requestBackend(url: String, method: String, headers: Map<String, String>, body: String?): JSONObject {
    val connection = URL(url).openConnection() as HttpURLConnection
    connection.requestMethod = method
    connection.connectTimeout = 15000
    connection.readTimeout = 30000
    connection.setRequestProperty("Accept", "application/json")
    headers.forEach { (k, v) -> connection.setRequestProperty(k, v) }
    if (body != null) {
        connection.doOutput = true
        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
    }
    try {
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val raw = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        val result = runCatching { JSONObject(raw) }.getOrElse { JSONObject().put("ok", false).put("error", "Respons backend tidak valid (HTTP $code).") }
        if (code !in 200..299 || !result.optBoolean("ok", true)) {
            val detail = result.optString("error", "Permintaan gagal (HTTP $code).")
            val codeName = result.optString("code")
            throw IllegalStateException(if (codeName.isNotBlank()) "$detail [$codeName]" else detail)
        }
        return result
    } finally { connection.disconnect() }
}
