DramaHub Android — UI Profile, History & AutoGoPay

Source project untuk AndroidForge. Unggah ZIP ini sebagai source project lalu jalankan Build APK.

Perubahan UI:
- Padding status bar/navigation bar agar header tidak menabrak jam HP.
- Menu horizontal: Trending, Terbaru, Kategori, Riwayat, Profil, Langganan.
- Profil menampilkan username, status, masa aktif, cek status, beli/perpanjang.
- Riwayat tontonan disimpan lokal di perangkat.
- Riwayat pembayaran memuat 50 transaksi terakhir dari backend.
- QRIS dapat diketuk untuk diperbesar, dengan tombol ✕ Tutup.
- Tombol Batalkan tersedia; tombol Buka pembayaran eksternal dihapus.
- Paket 1, 3, 7, 30 hari.
- Pemutar memiliki kontrol layar penuh.
- Episode 1–5 gratis; episode 6+ membutuhkan langganan aktif.

Backend yang menyertai perubahan:
- Ganti index.php di public_html/dramahub-api/ dengan file index.php patch terpisah.
- Ganti admin.php dengan file admin.php patch terpisah untuk opsi durasi 1/3/7/30 hari.
- Jangan mengganti config.php, admin-lib.php, atau database.
- Tabel payment_orders harus sudah ada dari migration-autogopay.sql.
- Harga paket dihitung sebagai autogopay.daily_price x jumlah hari.

Catatan penting:
- Source belum dibangun melalui AndroidForge dari lingkungan ini. Jalankan Build APK dan tes pada perangkat.
- Tombol Batalkan menandai order di database sebagai CANCELLED, tetapi QR yang sudah dibuat mungkin tetap berlaku di gateway sampai kedaluwarsa.
- Uji transaksi nominal kecil dan webhook/status gateway sebelum membagikan APK.
