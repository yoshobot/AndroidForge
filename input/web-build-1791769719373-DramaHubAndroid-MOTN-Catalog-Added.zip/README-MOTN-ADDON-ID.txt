DRAMAHUB - TAMBAHAN KATALOG MOVIE OF THE NIGHT

Perubahan pada source Android:
- Menambahkan menu Film di navigasi bawah.
- Mengambil katalog tambahan melalui endpoint backend motn_top dan motn_search.
- Menampilkan poster, judul, tipe, tahun, rating, sinopsis, dan tautan layanan streaming Indonesia bila tersedia.
- Tombol layanan membuka aplikasi/browser layanan streaming; API ini tidak menyediakan file video untuk diputar langsung di player DramaHub.
- QuickPlay, halaman drama, episode, pemutar, login, Nobar, dan fitur lain tetap dipertahankan.

PENTING:
- Pastikan backend hosting yang terpasang mendukung action=motn_top dan action=motn_search.
- Movie of the Night harus diaktifkan dan API key tersimpan di halaman admin.
- Jika daftar populer kosong/error, cek endpoint backend dan parameter API sesuai dokumentasi akun.
- Source ini belum dinyatakan berhasil build di AndroidForge; build harus dijalankan untuk memverifikasi kompilasi dan integrasi.
