DramaHub — Upgrade Kategori & UX Pencarian

Perubahan pada versi ini:
- Mempertahankan kolom pencarian ringkas (tinggi 52dp) dan tombol Cari ringkas.
- Halaman Kategori diberi judul dan deskripsi yang lebih jelas.
- Kartu kategori sekarang dapat diketuk; aplikasi mencoba mencari drama menggunakan nama kategori melalui endpoint pencarian yang sudah ada.
- Tampilan kategori diperbarui dengan ikon, jarak, dan indikator navigasi yang konsisten dengan tema DramaHub.

Catatan penting:
- Arsip ZIP dan perubahan source diperiksa, tetapi belum dikompilasi menjadi APK di lingkungan ini.
- Hasil kategori bergantung pada apakah endpoint pencarian backend mendukung pencarian berdasarkan nama kategori. Jika tidak, perlu dukungan endpoint kategori dari backend.
- Ini upgrade UX lanjutan; jangan anggap integrasi iklan/watermark telah diverifikasi hanya dari ZIP ini.

Build lewat AndroidForge. Jika gagal, kirim AndroidForge-logs.zip terbaru.
