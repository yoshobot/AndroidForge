DramaHub — Upgrade Kategori & UX Pencarian

Perubahan pada versi ini:
- Mempertahankan kolom pencarian ringkas (tinggi 52dp) dan tombol Cari ringkas.
- Halaman Kategori diberi judul dan deskripsi yang lebih jelas.
- Kartu kategori sekarang dapat diketuk; aplikasi mencoba mencari drama menggunakan nama kategori melalui endpoint pencarian yang sudah ada.
- Tampilan kategori diperbarui dengan ikon, jarak, dan indikator navigasi yang konsisten dengan tema DramaHub.

Catatan penting:
- Arsip ZIP dan perubahan source diperiksa, tetapi belum dikompilasi menjadi APK di lingkungan ini.
- Hasil kategori bergantung pada apakah endpoint pencarian backend mendukung pencarian berdasarkan nama kategori. Jika tidak, perlu dukungan endpoint kategori dari backend.
- Ini upgrade UX lanjutan; jangan anggap integrasi iklan/watermark telah diverifikasi hanya dari ZIP ini.

Build lewat AndroidForge. Jika gagal, kirim AndroidForge-logs.zip terbaru.


Patch lanjutan: penanganan iklan yang belum siap. Jika hitungan mencapai kelipatan tiga saat iklan belum selesai dimuat, aplikasi menandai iklan sebagai pending dan menampilkannya setelah iklan uji berhasil dimuat. Pemutaran episode tidak diblokir jika pemuatan iklan gagal. Perubahan ini belum diuji melalui kompilasi APK.


Compact Home Layout Revision:
- Banner dipadatkan dari 190dp menjadi 132dp.
- Kartu Lanjutkan Menonton diperkecil dan lebih ringkas.
- Kolom pencarian dipadatkan menjadi 46dp.
- Spasi judul katalog dikurangi agar lebih banyak ruang untuk grid drama.
- Source belum dikompilasi menjadi APK; build dan uji di AndroidForge.
\n\nPembaruan layout referensi (11 Okt 2026): beranda memakai pencarian ringkas di atas, tab Drama/Anime, filter horizontal, dan grid poster dua kolom yang lebih padat. Banner besar dan riwayat horizontal dipindahkan dari area atas agar katalog lebih cepat terlihat. Filter saat ini merupakan kontrol UI lokal dan belum menjamin filter backend khusus.\n