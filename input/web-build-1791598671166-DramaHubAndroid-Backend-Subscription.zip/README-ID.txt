DramaHub Android — Backend + Langganan

Source Android ini sudah diubah agar:
- Login dan pendaftaran akun melalui https://zione.store/dramahub-api/
- Token sesi disimpan di SharedPreferences.
- Daftar drama, detail, dan URL video diminta melalui backend; tidak ada secret QuickPlay di APK.
- Panel admin dan pengaturan secret QuickPlay dihapus dari APK.
- Akses konten bergantung pada status langganan server.
- Dependensi ExoPlayer HLS ditambahkan untuk mengatasi ClassNotFoundException HlsMediaSource$Factory.

Build di AndroidForge:
1. Pastikan backend sudah terpasang di https://zione.store/dramahub-api/ dan endpoint ?action=health merespons.
2. Pastikan config.php backend terisi dengan kredensial database dan secret QuickPlay yang valid.
3. Unggah ZIP ini sebagai source project ke AndroidForge lalu Build APK.
4. Instal APK. Daftar akun baru, lalu login.
5. Berikan username/ID pengguna kepada admin untuk aktivasi langganan lewat panel web.
6. Setelah admin mengaktifkan langganan, tekan "Periksa langganan lagi" di aplikasi.
7. Uji buka drama dan pilih episode.

Penting:
- ZIP adalah source project, bukan APK yang telah diuji di perangkat.
- Pemutaran tetap bergantung pada URL video valid dari QuickPlay dan izin provider.
- Backend yang dipasang harus sesuai schema.sql dari DramaHub Backend cPanel. Jangan impor schema ulang ke database berisi data tanpa backup.
- Panel admin hanya di website, bukan di APK.
