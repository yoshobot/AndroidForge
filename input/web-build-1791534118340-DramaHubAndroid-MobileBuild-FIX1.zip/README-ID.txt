DRAMAHUB ANDROID — PROJECT APK

Ini adalah project Android Studio native (Kotlin + Jetpack Compose), bukan file APK yang sudah dikompilasi. Build APK dari Android Studio.

FITUR VERSI AWAL
- Aplikasi Android dengan UI DramaHub sendiri
- Trending, terbaru, pencarian, kategori, detail drama
- URL backend dapat diatur dari dalam aplikasi
- Token Telegram/API secret tidak ditaruh di APK

SYARAT BACKEND
Aplikasi mengharapkan server HTTPS yang menyediakan:
GET /api/web/trending
GET /api/web/latest
GET /api/web/categories
GET /api/web/search?q=kata
GET /api/web/detail?id=ID_DRAMA

Project bot asli yang diberikan tidak memiliki endpoint HTTP tersebut secara default. Gunakan versi backend DramaHub yang ditambahkan route web, atau implementasikan endpoint itu pada server bot. Jangan letakkan token Telegram atau API secret di aplikasi Android.

CARA BUILD APK
1. Install Android Studio di komputer/laptop.
2. Ekstrak ZIP ini.
3. Android Studio > Open > pilih folder DramaHubAndroid.
4. Tunggu Gradle Sync selesai (butuh internet untuk mengunduh Gradle/dependensi).
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug biasanya tersedia di app/build/outputs/apk/debug/app-debug.apk.

Catatan: Build belum dijalankan di lingkungan ini karena Android SDK/Gradle belum tersedia. Jika ada error saat Gradle Sync/build, kirim screenshot error untuk diperbaiki. Backend publik HTTPS harus disiapkan sebelum data bot dapat dimuat.

BUILD CLOUD DARI HP (GitHub Actions)
1. Buat akun GitHub, lalu buat repository baru bernama DramaHubAndroid.
2. Upload seluruh isi ZIP project ke repository (pastikan folder .github/workflows/build-apk.yml ikut ter-upload).
3. Buka tab Actions di repository, pilih "Build DramaHub APK", tekan Run workflow.
4. Setelah proses hijau/berhasil, buka run tersebut dan unduh artifact "DramaHub-debug-apk". File artifact adalah ZIP; ekstrak di HP untuk mengambil app-debug.apk.
Catatan: repository publik membuat source code terlihat orang lain. Jangan upload token, API secret, atau config.json.
