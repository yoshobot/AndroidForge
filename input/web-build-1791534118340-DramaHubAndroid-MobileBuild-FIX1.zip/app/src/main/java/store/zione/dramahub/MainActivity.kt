package store.zione.dramahub

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

private val Bg = Color(0xFF0B1020)
private val Panel = Color(0xFF141E32)
private val Blue = Color(0xFF42A5F5)
private val Muted = Color(0xFF9AA9C3)

data class Drama(val id:String, val title:String, val cover:String="", val synopsis:String="", val status:String="", val author:String="", val episodes:String="")
data class DramaCategory(val id:String, val name:String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DramaHubApp(this) }
    }
}

@Composable
fun DramaHubApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("dramahub", Context.MODE_PRIVATE) }
    var baseUrl by remember { mutableStateOf(prefs.getString("base_url", "") ?: "") }
    var editUrl by remember { mutableStateOf(baseUrl) }
    var screen by remember { mutableStateOf("home") }
    var section by remember { mutableStateOf("trending") }
    var query by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("Masukkan URL backend bot untuk mulai.") }
    var loading by remember { mutableStateOf(false) }
    var dramas by remember { mutableStateOf(listOf<Drama>()) }
    var categories by remember { mutableStateOf(listOf<DramaCategory>()) }
    var selected by remember { mutableStateOf<Drama?>(null) }
    var detailJson by remember { mutableStateOf<JSONObject?>(null) }
    val scope = rememberCoroutineScope()

    fun load(path: String, label: String) {
        if (baseUrl.isBlank()) { screen = "settings"; message = "Atur URL backend bot dulu."; return }
        loading = true; message = "Mengambil data…"
        scope.launch {
            try {
                val json = withContext(Dispatchers.IO) { requestJson(baseUrl.trimEnd('/') + path) }
                when {
                    path.startsWith("/api/web/categories") -> {
                        val arr = getArray(json)
                        categories = (0 until arr.length()).mapNotNull { i ->
                            val o = arr.optJSONObject(i) ?: return@mapNotNull null
                            DramaCategory(o.optString("id", o.optString("slug")), o.optString("name", o.optString("display_name", "Kategori")))
                        }
                        screen = "categories"; message = "${categories.size} kategori"
                    }
                    path.startsWith("/api/web/detail") -> {
                        detailJson = json.optJSONObject("data") ?: json
                        screen = "detail"; message = "Detail drama"
                    }
                    else -> {
                        val arr = getArray(json)
                        dramas = (0 until arr.length()).mapNotNull { i ->
                            val o = arr.optJSONObject(i) ?: return@mapNotNull null
                            Drama(o.optString("id"), o.optString("title", o.optString("name", "Tanpa judul")),
                                o.optString("cover", o.optString("poster")), o.optString("synopsis"),
                                o.optString("status"), o.optString("author"),
                                o.optString("chapters", o.optString("total_episodes")))
                        }
                        screen = "home"; message = "$label · ${dramas.size} hasil"
                    }
                }
            } catch (e: Exception) {
                message = "Gagal terhubung: ${e.message ?: "periksa URL dan server"}"
                if (screen == "home") dramas = emptyList()
            } finally { loading = false }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Blue, background = Bg, surface = Panel)) {
        Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
            Column {
                Row(Modifier.fillMaxWidth().background(Panel).padding(horizontal=18.dp, vertical=16.dp), verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("🎬 DramaHub", fontSize=23.sp, fontWeight=FontWeight.Black, color=Color.White)
                        Text("Drama favoritmu, satu aplikasi", fontSize=12.sp, color=Muted)
                    }
                    Text("⚙", fontSize=25.sp, color=Blue, modifier=Modifier.clickable { editUrl=baseUrl; screen="settings" }.padding(6.dp))
                }
                Row(Modifier.fillMaxWidth().padding(horizontal=12.dp, vertical=10.dp), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    NavChip("🔥 Trending", section=="trending") { section="trending"; load("/api/web/trending","Trending") }
                    NavChip("🆕 Terbaru", section=="latest") { section="latest"; load("/api/web/latest","Drama terbaru") }
                    NavChip("📚 Kategori", screen=="categories") { load("/api/web/categories","Kategori") }
                }
                when(screen) {
                    "settings" -> Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
                        Text("Pengaturan koneksi", fontSize=22.sp, fontWeight=FontWeight.Bold, color=Color.White)
                        Text("Masukkan URL server bot DramaHub yang bisa diakses lewat HTTPS. Contoh: https://bot.domainkamu.com", color=Muted)
                        OutlinedTextField(value=editUrl, onValueChange={editUrl=it}, label={Text("URL backend HTTPS")}, singleLine=true, modifier=Modifier.fillMaxWidth())
                        Button(onClick={
                            baseUrl=editUrl.trim().trimEnd('/')
                            prefs.edit().putString("base_url",baseUrl).apply()
                            message="URL tersimpan"; screen="home"; load("/api/web/trending","Trending")
                        }, modifier=Modifier.fillMaxWidth()) { Text("Simpan & sambungkan") }
                        Text("Jangan masukkan token Telegram atau API secret ke aplikasi. Rahasia tetap disimpan di server.", color=Muted, fontSize=12.sp)
                    }
                    "categories" -> LazyColumn(Modifier.fillMaxSize().padding(horizontal=14.dp)) {
                        item { Text(message, color=Muted, modifier=Modifier.padding(8.dp)) }
                        items(categories) { c ->
                            Card(Modifier.fillMaxWidth().padding(vertical=5.dp), colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(14.dp)) {
                                Row(Modifier.padding(16.dp), verticalAlignment=Alignment.CenterVertically) {
                                    Text("📁", fontSize=22.sp)
                                    Spacer(Modifier.width(12.dp))
                                    Text(c.name, color=Color.White, fontWeight=FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                    "detail" -> {
                        val d = detailJson
                        if (d == null) Text("Detail tidak tersedia", color=Muted, modifier=Modifier.padding(20.dp))
                        else LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
                            item {
                                Row(verticalAlignment=Alignment.Top) {
                                    AsyncImage(model=d.optString("cover", selected?.cover), contentDescription=null, contentScale=ContentScale.Crop, modifier=Modifier.width(125.dp).height(175.dp).clip(RoundedCornerShape(14.dp)))
                                    Spacer(Modifier.width(14.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(d.optString("title", selected?.title ?: "Drama"), color=Color.White, fontSize=21.sp, fontWeight=FontWeight.Bold)
                                        Text("${d.optString("status")} · ${d.optString("author")}", color=Muted, fontSize=12.sp, modifier=Modifier.padding(top=6.dp))
                                        Text("Episode: ${d.optString("total_episodes", d.optString("chapters", "-"))}", color=Blue, modifier=Modifier.padding(top=10.dp))
                                    }
                                }
                                Text(d.optString("synopsis","Sinopsis belum tersedia."), color=Color.White, modifier=Modifier.padding(top=18.dp), lineHeight=22.sp)
                                Button(onClick={screen="home"}, modifier=Modifier.padding(top=18.dp)) { Text("← Kembali") }
                                Text("Pemutaran video langsung belum diaktifkan di versi awal.", color=Muted, fontSize=12.sp, modifier=Modifier.padding(top=10.dp))
                            }
                        }
                    }
                    else -> Column(Modifier.fillMaxSize()) {
                        Row(Modifier.fillMaxWidth().padding(horizontal=14.dp), verticalAlignment=Alignment.CenterVertically) {
                            OutlinedTextField(value=query, onValueChange={query=it}, label={Text("Cari drama…")}, singleLine=true, modifier=Modifier.weight(1f))
                            Spacer(Modifier.width(8.dp))
                            Button(onClick={ if(query.isNotBlank()) load("/api/web/search?q="+URLEncoder.encode(query,"UTF-8"),"Pencarian") }) { Text("Cari") }
                        }
                        Text(message, color=Muted, fontSize=12.sp, modifier=Modifier.padding(horizontal=16.dp, vertical=10.dp))
                        if(loading) LinearProgressIndicator(Modifier.fillMaxWidth())
                        LazyColumn(Modifier.fillMaxSize().padding(horizontal=12.dp)) {
                            items(dramas) { drama ->
                                Card(Modifier.fillMaxWidth().padding(vertical=6.dp).clickable {
                                    selected=drama
                                    load("/api/web/detail?id="+URLEncoder.encode(drama.id,"UTF-8"),"Detail")
                                }, colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(16.dp)) {
                                    Row(Modifier.padding(10.dp), verticalAlignment=Alignment.Top) {
                                        AsyncImage(model=drama.cover, contentDescription=null, contentScale=ContentScale.Crop, modifier=Modifier.width(92.dp).height(126.dp).clip(RoundedCornerShape(10.dp)))
                                        Spacer(Modifier.width(12.dp))
                                        Column(Modifier.weight(1f).padding(top=4.dp)) {
                                            Text(drama.title, color=Color.White, fontWeight=FontWeight.Bold, fontSize=16.sp, maxLines=2, overflow=TextOverflow.Ellipsis)
                                            Text("${drama.status} ${if(drama.episodes.isNotBlank()) "· ${drama.episodes} episode" else ""}", color=Blue, fontSize=12.sp, modifier=Modifier.padding(top=7.dp))
                                            Text(drama.synopsis.ifBlank { drama.author }, color=Muted, fontSize=13.sp, maxLines=3, overflow=TextOverflow.Ellipsis, modifier=Modifier.padding(top=8.dp))
                                        }
                                    }
                                }
                            }
                            if(!loading && dramas.isEmpty()) item { Text("Belum ada drama ditampilkan. Periksa URL server dan pastikan backend web bot sudah dipasang.", color=Muted, modifier=Modifier.padding(18.dp)) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NavChip(label:String, selected:Boolean, onClick:()->Unit) {
    Surface(color=if(selected) Blue else Panel, shape=RoundedCornerShape(12.dp), modifier=Modifier.clickable(onClick=onClick)) {
        Text(label, color=if(selected) Color(0xFF07101C) else Color.White, fontWeight=FontWeight.SemiBold, fontSize=12.sp, modifier=Modifier.padding(horizontal=12.dp, vertical=10.dp))
    }
}
private fun getArray(json:JSONObject): JSONArray {
    for (key in listOf("data","items","results","categories")) {
        val a=json.optJSONArray(key)
        if(a!=null) return a
    }
    return JSONArray()
}
private fun requestJson(url:String):JSONObject {
    val connection=(URL(url).openConnection() as HttpURLConnection)
    connection.requestMethod="GET"
    connection.connectTimeout=12000
    connection.readTimeout=20000
    connection.setRequestProperty("Accept","application/json")
    try {
        val code=connection.responseCode
        val stream=if(code in 200..299) connection.inputStream else connection.errorStream
        val body=stream.bufferedReader().use { it.readText() }
        if(code !in 200..299) throw IllegalStateException(JSONObject(body).optString("error","HTTP $code"))
        return JSONObject(body)
    } finally { connection.disconnect() }
}
