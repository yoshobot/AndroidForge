DramaHub — Unduhan Wajib Update di Dalam Aplikasi

Perubahan:
- APK diunduh langsung oleh proses di dalam aplikasi DramaHub, bukan memakai DownloadManager/notifikasi unduhan sistem.
- Dialog wajib update menampilkan progress bar dan persentase unduhan.
- Setelah unduhan selesai, aplikasi memanggil pemasang Android menggunakan FileProvider.
- File sementara yang tidak selesai diunduh dihapus ketika terjadi kegagalan.
- URL harus HTTPS; pengalihan ke HTTP ditolak.

Batasan Android:
- Konfirmasi pemasangan tetap dilakukan oleh Android; aplikasi biasa tidak boleh memasang APK secara diam-diam.
- Jika izin "Instal aplikasi tidak dikenal" belum diberikan, pengguna diarahkan ke Pengaturan Android, lalu kembali ke DramaHub dan menekan tombol update lagi.
- APK update harus memakai applicationId/package name dan sertifikat penandatanganan yang sama dengan APK terpasang.
- APK yang diunduh harus benar-benar versi baru dengan versionCode lebih tinggi daripada versi terpasang.

Belum dikompilasi atau diuji di perangkat. Build melalui AndroidForge, lalu uji unduh pada jaringan yang stabil sebelum mengaktifkan force update untuk semua pengguna.
