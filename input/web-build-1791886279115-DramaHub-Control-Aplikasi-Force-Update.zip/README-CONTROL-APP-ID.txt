DRAMAHUB — KONTROL APLIKASI & FORCE UPDATE

SOURCE ANDROID
- versionCode: 7
- versionName: 1.3.3
- App ID AdMob DramaHub dipertahankan.
- APK mengecek app-config.php setiap 5 detik.
- Mode pemeliharaan menampilkan layar blokir dan menghentikan video.
- Force update membandingkan versionCode APK dengan min_version_code dari server.
- Jika APK terlalu lama, tombol Perbarui Sekarang membuka update_url HTTPS dari server.

PATCH SERVER YANG IKUT DISERTAKAN
- server/app-config.php: respons JSON konfigurasi iklan + kontrol aplikasi.
- server/admin/index.php: panel admin dengan bagian Kontrol aplikasi.

CARA PASANG SERVER
1. Backup file /public_html/app-config.php dan /public_html/admin/index.php.
2. Upload server/app-config.php untuk menggantikan /public_html/app-config.php.
3. Upload server/admin/index.php untuk menggantikan /public_html/admin/index.php.
4. JANGAN mengganti config.php. Patch membaca config.php yang sudah ada.
5. Pastikan admin-lib.php yang saat ini dipakai panel tetap ada di folder parent /public_html/admin-lib.php.

CARA MENGGUNAKAN PANEL
- Masuk /admin/.
- Bagian Kontrol aplikasi: centang Mode pemeliharaan untuk memblokir aplikasi yang sedang digunakan; hilangkan centang untuk membuka lagi.
- Minimum versionCode = 0 berarti force update nonaktif.
- APK source ini versionCode 7. Setelah APK versi 7 berhasil dibuild dan diunggah ke URL update, isi minimum versionCode 7 untuk memaksa versi di bawah 7 melakukan update.
- Jangan set minimum versionCode lebih tinggi dari APK yang benar-benar tersedia di URL update, atau pengguna akan terjebak pada layar update.
- URL download default: https://dramahubx.my.id/DramaHub.apk. Pastikan file APK versi baru memang diunggah di lokasi itu.

PENTING
- ZIP ini adalah source project dan patch PHP, bukan APK hasil build. Build APK di AndroidForge/GitHub Actions. Build tidak dijalankan di lingkungan ini karena Gradle tidak tersedia.
- Kontrol aplikasi di Android baru berfungsi pada APK yang berisi kode versi ini; APK lama tidak bisa menerima fitur baru sampai diperbarui.
- Pemeliharaan dibaca setiap sekitar 5 detik saat koneksi server tersedia. Jika internet putus, aplikasi mempertahankan status kontrol terakhir yang diterima.
