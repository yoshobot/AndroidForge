DRAMAHUB UPDATE FIX V3

Perbaikan: versionCode dinaikkan otomatis saat build GitHub Actions (minimal 6, lalu mengikuti GITHUB_RUN_NUMBER). applicationId tetap com.dramahub.app.

PENTING UNTUK INSTAL UPDATE:
1. Upload ZIP ini ke folder input/ AndroidForge seperti biasa.
2. Jalankan workflow "DramaHub Signed Release" dari panel.
3. Unduh artifact bernama "DramaHub-signed-release" dari run yang baru selesai.
4. Ekstrak ZIP artifact dan instal APK di dalamnya.
5. JANGAN gunakan AndroidForge-app-debug.apk untuk tes update; gunakan APK dari artifact signed release.

APK hanya bisa menimpa aplikasi lama jika keystore/sertifikat dan applicationId sama. Workflow harus memakai secret keystore lama yang cocok dengan base.apk. Jangan uninstall aplikasi lama jika instalasi gagal.

Catatan: ZIP ini memperbaiki konfigurasi versi. Keberhasilan instalasi tetap perlu diuji dari APK signed release yang dihasilkan AndroidForge.
