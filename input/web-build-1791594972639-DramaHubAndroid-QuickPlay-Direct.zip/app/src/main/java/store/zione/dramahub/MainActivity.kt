package store.zione.dramahub

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

private val Bg = Color(0xFF0B1020)
private val Panel = Color(0xFF141E32)
private val Blue = Color(0xFF42A5F5)
private val Muted = Color(0xFF9AA9C3)

data class Drama(val id:String, val title:String, val cover:String="", val synopsis:String="", val status:String="", val author:String="", val episodes:String="")
data class DramaCategory(val id:String, val name:String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DramaHubApp(this) }
    }
}

@Composable
fun DramaHubApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("dramahub", Context.MODE_PRIVATE) }
    var apiSecret by remember { mutableStateOf(prefs.getString("quickplay_secret", "") ?: "") }
    var editSecret by remember { mutableStateOf(apiSecret) }
    var category by remember { mutableStateOf(prefs.getString("category_p", "freereels") ?: "freereels") }
    var editCategory by remember { mutableStateOf(category) }
    var screen by remember { mutableStateOf("home") }
    var section by remember { mutableStateOf("trending") }
    var query by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("DramaHub siap memakai QuickPlay langsung.") }
    var loading by remember { mutableStateOf(false) }
    var dramas by remember { mutableStateOf(listOf<Drama>()) }
    var categories by remember { mutableStateOf(listOf<DramaCategory>()) }
    var selected by remember { mutableStateOf<Drama?>(null) }
    var detailJson by remember { mutableStateOf<JSONObject?>(null) }
    val scope = rememberCoroutineScope()

    fun load(path: String, label: String) {
        if (apiSecret.isBlank()) { screen = "settings"; message = "Masukkan API secret QuickPlay."; return }
        loading = true; message = "Mengambil data dari QuickPlay…"
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    val endpoint = when {
                        path.startsWith("/api/web/trending") || path.startsWith("/api/web/latest") -> "home"
                        path.startsWith("/api/web/categories") -> "categories"
                        path.startsWith("/api/web/search") -> "search"
                        path.startsWith("/api/web/detail") -> "detail"
                        else -> throw IllegalArgumentException("Endpoint tidak dikenal")
                    }
                    val params = linkedMapOf<String, String>()
                    when (endpoint) {
                        "home" -> { params["category_p"] = category; params["lang"] = "id"; params["page"] = "1" }
                        "search" -> {
                            params["category_p"] = category
                            params["lang"] = "id"
                            params["page"] = "1"
                            params["limit"] = "20"
                            val q = path.substringAfter("q=", "").substringBefore("&")
                            params["q"] = java.net.URLDecoder.decode(q, "UTF-8")
                        }
                        "detail" -> {
                            val rawId = path.substringAfter("id=", "").substringBefore("&")
                            val id = java.net.URLDecoder.decode(rawId, "UTF-8")
                            val pieces = id.split("~", limit = 2)
                            params["category_p"] = if (pieces.size == 2) pieces[0] else category
                            params["id"] = if (pieces.size == 2) pieces[1] else id
                            params["lang"] = "id"
                        }
                    }
                    val apiPath = when (endpoint) {
                        "home" -> "/api/v2/home"
                        "categories" -> "/api/v2/categories"
                        "search" -> "/api/v2/search"
                        else -> "/api/v2/detail"
                    }
                    quickPlayRequest("https://api.quickplay.my.id", apiPath, params, apiSecret)
                }
                when {
                    path.startsWith("/api/web/categories") -> {
                        val arr = getArray(result)
                        categories = (0 until arr.length()).mapNotNull { i ->
                            val o = arr.optJSONObject(i) ?: return@mapNotNull null
                            DramaCategory(o.optString("id", o.optString("slug", o.optString("name"))),
                                o.optString("display_name", o.optString("name", o.optString("slug", "Kategori"))))
                        }
                        screen = "categories"; message = "${categories.size} kategori dari QuickPlay"
                    }
                    path.startsWith("/api/web/detail") -> {
                        val data = result.optJSONObject("data") ?: result
                        detailJson = normalizeQuickPlayDetail(data)
                        screen = "detail"; message = "Detail drama dari QuickPlay"
                    }
                    else -> {
                        val arr = getArray(result)
                        dramas = (0 until arr.length()).mapNotNull { i ->
                            val o = arr.optJSONObject(i) ?: return@mapNotNull null
                            val rawId = o.optString("id", o.optString("bookId", o.optString("drama_id")))
                            val finalId = if (rawId.isNotBlank() && !rawId.contains("~")) "$category~$rawId" else rawId
                            Drama(finalId, o.optString("title", o.optString("name", o.optString("bookName", "Tanpa judul"))),
                                o.optString("cover", o.optString("poster", o.optString("cover_url", o.optString("image")))),
                                o.optString("synopsis", o.optString("description", o.optString("desc"))),
                                o.optString("status"), o.optString("author"),
                                o.optString("chapters", o.optString("total_episodes", o.optString("episode_count"))))
                        }
                        screen = "home"; message = "$label · ${dramas.size} hasil dari QuickPlay"
                    }
                }
            } catch (e: Exception) {
                message = "QuickPlay gagal: ${e.message ?: "periksa API secret/koneksi"}"
                if (screen == "home") dramas = emptyList()
            } finally { loading = false }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Blue, background = Bg, surface = Panel)) {
        Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
            Column {
                Row(Modifier.fillMaxWidth().background(Panel).padding(horizontal=18.dp, vertical=16.dp), verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("🎬 DramaHub", fontSize=23.sp, fontWeight=FontWeight.Black, color=Color.White)
                        Text("Drama favoritmu, satu aplikasi", fontSize=12.sp, color=Muted)
                    }
                    Text("⚙", fontSize=25.sp, color=Blue, modifier=Modifier.clickable { editSecret=apiSecret; editCategory=category; screen="settings" }.padding(6.dp))
                }
                Row(Modifier.fillMaxWidth().padding(horizontal=12.dp, vertical=10.dp), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    NavChip("🔥 Trending", section=="trending") { section="trending"; load("/api/web/trending","Trending") }
                    NavChip("🆕 Terbaru", section=="latest") { section="latest"; load("/api/web/latest","Drama terbaru") }
                    NavChip("📚 Kategori", screen=="categories") { load("/api/web/categories","Kategori") }
                }
                when(screen) {
                    "settings" -> Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
                        Text("QuickPlay API", fontSize=22.sp, fontWeight=FontWeight.Bold, color=Color.White)
                        Text("Aplikasi mengambil data langsung dari QuickPlay. Tidak perlu URL bot, Pterodactyl, atau LocalTunnel.", color=Muted)
                        OutlinedTextField(value=editSecret, onValueChange={editSecret=it}, label={Text("QuickPlay API secret")}, singleLine=true, modifier=Modifier.fillMaxWidth())
                        OutlinedTextField(value=editCategory, onValueChange={editCategory=it}, label={Text("Kategori provider (category_p)")}, singleLine=true, modifier=Modifier.fillMaxWidth())
                        Button(onClick={
                            apiSecret=editSecret.trim()
                            category=editCategory.trim().ifBlank { "freereels" }
                            prefs.edit().putString("quickplay_secret",apiSecret).putString("category_p",category).remove("base_url").apply()
                            message="Pengaturan QuickPlay tersimpan"; screen="home"; section="trending"; load("/api/web/trending","Trending")
                        }, modifier=Modifier.fillMaxWidth()) { Text("Simpan & ambil drama") }
                        Text("Peringatan: API secret yang disimpan di aplikasi dapat diekstrak dari perangkat. Untuk APK publik, gunakan backend proxy milik sendiri.", color=Muted, fontSize=12.sp)
                    }
                    "categories" -> LazyColumn(Modifier.fillMaxSize().padding(horizontal=14.dp)) {
                        item { Text(message, color=Muted, modifier=Modifier.padding(8.dp)) }
                        items(categories) { c ->
                            Card(Modifier.fillMaxWidth().padding(vertical=5.dp), colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(14.dp)) {
                                Row(Modifier.padding(16.dp), verticalAlignment=Alignment.CenterVertically) {
                                    Text("📁", fontSize=22.sp)
                                    Spacer(Modifier.width(12.dp))
                                    Text(c.name, color=Color.White, fontWeight=FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                    "detail" -> {
                        val d = detailJson
                        if (d == null) Text("Detail tidak tersedia", color=Muted, modifier=Modifier.padding(20.dp))
                        else LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
                            item {
                                Row(verticalAlignment=Alignment.Top) {
                                    AsyncImage(model=d.optString("cover", selected?.cover), contentDescription=null, contentScale=ContentScale.Crop, modifier=Modifier.width(125.dp).height(175.dp).clip(RoundedCornerShape(14.dp)))
                                    Spacer(Modifier.width(14.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(d.optString("title", selected?.title ?: "Drama"), color=Color.White, fontSize=21.sp, fontWeight=FontWeight.Bold)
                                        Text("${d.optString("status")} · ${d.optString("author")}", color=Muted, fontSize=12.sp, modifier=Modifier.padding(top=6.dp))
                                        Text("Episode: ${d.optString("total_episodes", d.optString("chapters", "-"))}", color=Blue, modifier=Modifier.padding(top=10.dp))
                                    }
                                }
                                Text(d.optString("synopsis","Sinopsis belum tersedia."), color=Color.White, modifier=Modifier.padding(top=18.dp), lineHeight=22.sp)
                                Button(onClick={screen="home"}, modifier=Modifier.padding(top=18.dp)) { Text("← Kembali") }
                                Text("Pemutaran video langsung belum diaktifkan di versi awal.", color=Muted, fontSize=12.sp, modifier=Modifier.padding(top=10.dp))
                            }
                        }
                    }
                    else -> Column(Modifier.fillMaxSize()) {
                        Row(Modifier.fillMaxWidth().padding(horizontal=14.dp), verticalAlignment=Alignment.CenterVertically) {
                            OutlinedTextField(value=query, onValueChange={query=it}, label={Text("Cari drama…")}, singleLine=true, modifier=Modifier.weight(1f))
                            Spacer(Modifier.width(8.dp))
                            Button(onClick={ if(query.isNotBlank()) load("/api/web/search?q="+URLEncoder.encode(query,"UTF-8"),"Pencarian") }) { Text("Cari") }
                        }
                        Text(message, color=Muted, fontSize=12.sp, modifier=Modifier.padding(horizontal=16.dp, vertical=10.dp))
                        if(loading) LinearProgressIndicator(Modifier.fillMaxWidth())
                        LazyColumn(Modifier.fillMaxSize().padding(horizontal=12.dp)) {
                            items(dramas) { drama ->
                                Card(Modifier.fillMaxWidth().padding(vertical=6.dp).clickable {
                                    selected=drama
                                    load("/api/web/detail?id="+URLEncoder.encode(drama.id,"UTF-8"),"Detail")
                                }, colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(16.dp)) {
                                    Row(Modifier.padding(10.dp), verticalAlignment=Alignment.Top) {
                                        AsyncImage(model=drama.cover, contentDescription=null, contentScale=ContentScale.Crop, modifier=Modifier.width(92.dp).height(126.dp).clip(RoundedCornerShape(10.dp)))
                                        Spacer(Modifier.width(12.dp))
                                        Column(Modifier.weight(1f).padding(top=4.dp)) {
                                            Text(drama.title, color=Color.White, fontWeight=FontWeight.Bold, fontSize=16.sp, maxLines=2, overflow=TextOverflow.Ellipsis)
                                            Text("${drama.status} ${if(drama.episodes.isNotBlank()) "· ${drama.episodes} episode" else ""}", color=Blue, fontSize=12.sp, modifier=Modifier.padding(top=7.dp))
                                            Text(drama.synopsis.ifBlank { drama.author }, color=Muted, fontSize=13.sp, maxLines=3, overflow=TextOverflow.Ellipsis, modifier=Modifier.padding(top=8.dp))
                                        }
                                    }
                                }
                            }
                            if(!loading && dramas.isEmpty()) item { Text("Belum ada drama ditampilkan. Periksa URL server dan pastikan backend web bot sudah dipasang.", color=Muted, modifier=Modifier.padding(18.dp)) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NavChip(label:String, selected:Boolean, onClick:()->Unit) {
    Surface(color=if(selected) Blue else Panel, shape=RoundedCornerShape(12.dp), modifier=Modifier.clickable(onClick=onClick)) {
        Text(label, color=if(selected) Color(0xFF07101C) else Color.White, fontWeight=FontWeight.SemiBold, fontSize=12.sp, modifier=Modifier.padding(horizontal=12.dp, vertical=10.dp))
    }
}
private fun getArray(json:JSONObject): JSONArray {
    for (key in listOf("data","items","results","categories")) {
        val a=json.optJSONArray(key)
        if(a!=null) return a
    }
    val data = json.optJSONObject("data")
    if (data != null) for (key in listOf("data","items","results","categories")) {
        val a = data.optJSONArray(key)
        if (a != null) return a
    }
    return JSONArray()
}

private fun normalizeQuickPlayDetail(source: JSONObject): JSONObject {
    val out = JSONObject(source.toString())
    if (!out.has("title")) out.put("title", source.optString("name", source.optString("bookName", "Drama")))
    if (!out.has("cover")) out.put("cover", source.optString("poster", source.optString("cover_url", source.optString("image", ""))))
    if (!out.has("synopsis")) out.put("synopsis", source.optString("description", source.optString("desc", "")))
    if (!out.has("total_episodes")) out.put("total_episodes", source.optString("chapters", source.optString("episode_count", "")))
    return out
}

private fun quickPlayRequest(base: String, path: String, params: Map<String, String>, secret: String): JSONObject {
    val query = params.entries.joinToString("&") { (k, v) ->
        java.net.URLEncoder.encode(k, "UTF-8") + "=" +
            java.net.URLEncoder.encode(v, "UTF-8").replace("+", "%20")
    }
    val pathQuery = path + if (query.isNotEmpty()) "?$query" else ""
    val timestamp = System.currentTimeMillis().toString()
    val mac = javax.crypto.Mac.getInstance("HmacSHA256")
    mac.init(javax.crypto.spec.SecretKeySpec(secret.toByteArray(Charsets.UTF_8), "HmacSHA256"))
    val signature = mac.doFinal("GET:$pathQuery:$timestamp".toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it) }
    return requestJson(base.trimEnd('/') + pathQuery, mapOf("X-Timestamp" to timestamp, "X-Signature" to signature))
}
private fun requestJson(url:String, headers: Map<String, String> = emptyMap()):JSONObject {
    val connection=(URL(url).openConnection() as HttpURLConnection)
    connection.requestMethod="GET"
    connection.connectTimeout=12000
    connection.readTimeout=20000
    connection.setRequestProperty("Accept","application/json")
    headers.forEach { (key, value) -> connection.setRequestProperty(key, value) }
    try {
        val code=connection.responseCode
        val stream=if(code in 200..299) connection.inputStream else connection.errorStream
        val body=stream.bufferedReader().use { it.readText() }
        if(code !in 200..299) throw IllegalStateException(JSONObject(body).optString("error","HTTP $code"))
        return JSONObject(body)
    } finally { connection.disconnect() }
}
