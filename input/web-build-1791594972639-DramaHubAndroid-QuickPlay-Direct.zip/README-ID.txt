DRAMAHUB ANDROID — QUICKPLAY DIRECT

Project Android native Kotlin + Jetpack Compose. Aplikasi mengambil data langsung dari QuickPlay:
- GET /api/v2/home
- GET /api/v2/categories
- GET /api/v2/search
- GET /api/v2/detail

Tidak lagi membutuhkan backend bot, Pterodactyl, LocalTunnel, atau zione.store sebagai proxy untuk membaca katalog.

SETUP
1. Build APK dari project ini.
2. Buka aplikasi, ketuk ikon ⚙.
3. Masukkan QuickPlay API secret yang aktif.
4. Isi category_p, default freereels.
5. Simpan & ambil drama.

PENTING
- QuickPlay menggunakan X-Timestamp dan X-Signature HMAC-SHA256 dengan format:
  GET:<path+query>:<timestamp>
- Secret yang dimasukkan di aplikasi disimpan lokal pada perangkat, tetapi dapat diekstrak dari APK/perangkat. Jangan distribusikan APK dengan secret yang kamu anggap rahasia atau memiliki kuota berbayar tanpa proteksi. Untuk rilis publik, backend proxy HTTPS tetap lebih aman.
- Versi ini mendukung katalog, pencarian, kategori, dan detail dasar. Pemutaran video belum diimplementasikan.
- Build cloud tersedia melalui .github/workflows/build-apk.yml.
