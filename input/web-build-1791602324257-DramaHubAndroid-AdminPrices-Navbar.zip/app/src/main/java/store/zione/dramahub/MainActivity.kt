package store.zione.dramahub

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.platform.LocalContext
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

private const val API_BASE = "https://zione.store/dramahub-api/"
private val Bg = Color(0xFF080D19)
private val Panel = Color(0xFF111B2D)
private val Panel2 = Color(0xFF18263D)
private val Blue = Color(0xFF42A5F5)
private val Muted = Color(0xFF9AA9C3)
private val White = Color(0xFFF4F7FF)

data class Drama(val id:String, val title:String, val cover:String="", val synopsis:String="", val status:String="", val author:String="", val episodes:String="")
data class DramaCategory(val id:String, val name:String)
data class WatchEntry(val id:String, val title:String, val cover:String, val episode:Int, val time:Long)
data class PaymentEntry(val order:String, val amount:Int, val status:String, val days:Int, val created:String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8,13,25)
        window.navigationBarColor = android.graphics.Color.rgb(8,13,25)
        if (android.os.Build.VERSION.SDK_INT >= 29) { window.isNavigationBarContrastEnforced = false; window.isStatusBarContrastEnforced = false }
        setContent { DramaHubApp(this) }
    }
}

@Composable
fun DramaHubApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("dramahub", Context.MODE_PRIVATE) }
    var token by remember { mutableStateOf(prefs.getString("session_token", "") ?: "") }
    var screen by remember { mutableStateOf(if (token.isBlank()) "auth" else "checking") }
    var authMode by remember { mutableStateOf("login") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var query by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("Masuk untuk melanjutkan.") }
    var loading by remember { mutableStateOf(false) }
    var dramas by remember { mutableStateOf(listOf<Drama>()) }
    var categories by remember { mutableStateOf(listOf<DramaCategory>()) }
    var selected by remember { mutableStateOf<Drama?>(null) }
    var detailJson by remember { mutableStateOf<JSONObject?>(null) }
    var selectedEpisode by remember { mutableIntStateOf(0) }
    var videoUrl by remember { mutableStateOf("") }
    var videoLoading by remember { mutableStateOf(false) }
    var videoError by remember { mutableStateOf("") }
    var subscriptionActive by remember { mutableStateOf(false) }
    var subscriptionExpiry by remember { mutableStateOf("") }
    var showSubscriptionPrompt by remember { mutableStateOf(false) }
    var showFullscreenPlayer by remember { mutableStateOf(false) }
    var paymentOrderId by remember { mutableStateOf("") }
    var paymentQrUrl by remember { mutableStateOf("") }
    var paymentCheckoutUrl by remember { mutableStateOf("") }
    var paymentAmount by remember { mutableIntStateOf(1000) }
    val planPrices = remember { mutableStateMapOf(1 to 1000, 3 to 2500, 7 to 5000, 30 to 15000) }
    var paymentMessage by remember { mutableStateOf("") }
    var paymentLoading by remember { mutableStateOf(false) }
    var showQrZoom by remember { mutableStateOf(false) }
    var selectedPlanDays by remember { mutableIntStateOf(1) }
    var watchHistory by remember { mutableStateOf(loadWatchHistory(prefs.getString("watch_history", "[]") ?: "[]")) }
    var paymentHistory by remember { mutableStateOf(listOf<PaymentEntry>()) }
    var accountLabel by remember { mutableStateOf("") }
    var section by remember { mutableStateOf("trending") }
    val scope = rememberCoroutineScope()
    var player by remember { mutableStateOf<ExoPlayer?>(null) }

    fun stopPlayer() { player?.release(); player = null }

    fun load(path: String, label: String) {
        if (token.isBlank()) { screen = "auth"; message = "Silakan login terlebih dahulu."; return }
        loading = true
        message = "Memuat $label…"
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    val action = when {
                        path == "categories" -> "categories"
                        path.startsWith("search:") -> "search"
                        path.startsWith("detail:") -> "detail"
                        else -> "trending"
                    }
                    val params = linkedMapOf<String,String>()
                    when {
                        action == "search" -> params["q"] = path.substringAfter("search:")
                        action == "detail" -> params["id"] = path.substringAfter("detail:")
                    }
                    backendGet(action, params, token)
                }
                when {
                    path == "categories" -> {
                        val arr = getArray(result)
                        categories = (0 until arr.length()).mapNotNull { i ->
                            arr.optJSONObject(i)?.let { o ->
                                val id = o.optString("name", o.optString("slug", o.optString("id")))
                                DramaCategory(id, o.optString("display_name", o.optString("name", o.optString("slug", "Kategori"))))
                            }
                        }
                        screen = "categories"
                        message = "${categories.size} kategori tersedia"
                    }
                    path.startsWith("detail:") -> {
                        val data = result.optJSONObject("data") ?: result
                        detailJson = normalizeDetail(data)
                        screen = "detail"
                        selectedEpisode = 0
                        videoUrl = ""
                        videoError = ""
                        stopPlayer()
                        message = "Pilih episode untuk mulai menonton."
                    }
                    else -> {
                        val arr = getArray(result)
                        dramas = (0 until arr.length()).mapNotNull { i ->
                            arr.optJSONObject(i)?.let { o ->
                                val rawId = o.optString("id", o.optString("bookId", o.optString("drama_id")))
                                val finalId = if (rawId.isNotBlank() && !rawId.contains("~")) "freereels~$rawId" else rawId
                                Drama(
                                    finalId,
                                    o.optString("title", o.optString("name", o.optString("bookName", "Tanpa judul"))),
                                    o.optString("cover", o.optString("poster", o.optString("cover_url", o.optString("image")))),
                                    o.optString("synopsis", o.optString("description", o.optString("desc"))),
                                    o.optString("status"),
                                    o.optString("author"),
                                    o.optString("chapters", o.optString("total_episodes", o.optString("episode_count")))
                                )
                            }
                        }
                        screen = "home"
                        message = "$label · ${dramas.size} judul"
                    }
                }
            } catch (e: Exception) {
                val err = e.message ?: "Permintaan gagal"
                if (err.contains("AUTH_REQUIRED", true) || err.contains("Sesi tidak valid", true)) {
                    token = ""
                    prefs.edit().remove("session_token").apply()
                    screen = "auth"
                } else if (err.contains("SUBSCRIPTION_REQUIRED", true) || err.contains("Langganan tidak aktif", true)) {
                    subscriptionActive = false
                    videoError = err
                }
                message = err
            } finally { loading = false }
        }
    }

    fun checkSubscriptionAndContinue() {
        if (token.isBlank()) { screen = "auth"; return }
        loading = true
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) { backendGet("me", emptyMap(), token) }
                val user = result.optJSONObject("user")
                accountLabel = user?.optString("username", username).orEmpty()
                subscriptionActive = result.optBoolean("active", false)
                subscriptionExpiry = result.optString("expires_at", "")
                // Semua pengguna dapat menjelajahi katalog. Langganan hanya diperlukan untuk episode 6 ke atas.
                screen = "home"
                load("trending", "Trending")
                message = if (subscriptionActive) "Selamat datang kembali." else "Episode 1–5 gratis · episode 6 ke atas perlu langganan."
            } catch (e: Exception) {
                token = ""
                prefs.edit().remove("session_token").apply()
                screen = "auth"
                message = e.message ?: "Sesi tidak valid. Silakan login ulang."
            } finally { loading = false }
        }
    }

    fun submitAuth(register: Boolean) {
        if (username.trim().length < 4 || password.length < 8) {
            message = "Username minimal 4 karakter dan password minimal 8 karakter."
            return
        }
        loading = true
        message = if (register) "Membuat akun…" else "Memeriksa akun…"
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    backendPost(if (register) "register" else "login",
                        JSONObject().put("username", username.trim()).put("password", password))
                }
                if (register) {
                    authMode = "login"
                    password = ""
                    message = "Pendaftaran berhasil. Login untuk menjelajahi katalog. Episode 1–5 gratis; episode 6+ bisa dibeli di aplikasi."
                } else {
                    token = result.optString("token")
                    if (token.isBlank()) throw IllegalStateException("Server tidak mengembalikan token login.")
                    prefs.edit().putString("session_token", token).apply()
                    checkSubscriptionAndContinue()
                }
            } catch (e: Exception) {
                message = e.message ?: "Login/pendaftaran gagal."
            } finally { loading = false }
        }
    }

    fun logout() {
        scope.launch { withContext(Dispatchers.IO) { runCatching { backendGet("logout", emptyMap(), token) } } }
        stopPlayer()
        token = ""
        prefs.edit().remove("session_token").apply()
        screen = "auth"
        authMode = "login"
        dramas = emptyList()
        detailJson = null
        selected = null
        message = "Kamu sudah keluar."
    }

    fun playEpisode(number: Int) {
        if (number < 1 || number > 1000) return
        if (number > 5 && !subscriptionActive) {
            showSubscriptionPrompt = true
            videoError = "Episode $number dan seterusnya khusus pelanggan berlangganan."
            return
        }
        videoLoading = true
        videoError = ""
        videoUrl = ""
        selectedEpisode = number
        val watched = WatchEntry(selected?.id ?: "", selected?.title ?: "Drama", selected?.cover ?: "", number, System.currentTimeMillis())
        watchHistory = (listOf(watched) + watchHistory.filterNot { it.id == watched.id && it.episode == watched.episode }).take(100)
        prefs.edit().putString("watch_history", watchHistoryToJson(watchHistory)).apply()
        stopPlayer()
        scope.launch {
            try {
                val id = selected?.id ?: throw IllegalStateException("ID drama tidak tersedia.")
                val response = withContext(Dispatchers.IO) {
                    backendGet("video", linkedMapOf("id" to id, "episode" to number.toString()), token)
                }
                val data = response.optJSONObject("data") ?: response.optJSONObject("episode") ?: response
                val found = collectVideoUrls(data)
                val url = found.firstOrNull { it.contains(".m3u8", true) }
                    ?: found.firstOrNull { it.contains(".mp4", true) }
                    ?: found.firstOrNull { it.contains(".mpd", true) }
                    ?: found.firstOrNull()
                if (url.isNullOrBlank()) throw IllegalStateException("Backend tidak menerima URL video dari QuickPlay untuk episode ini.")
                videoUrl = url
                withContext(Dispatchers.Main) {
                    player = ExoPlayer.Builder(context).build().also { p ->
                        p.setMediaItem(MediaItem.fromUri(url))
                        p.prepare()
                        p.playWhenReady = true
                    }
                }
            } catch (e: Exception) {
                videoError = e.message ?: "Video gagal dimuat."
            } finally { videoLoading = false }
        }
    }

    fun createPayment(days: Int = selectedPlanDays) {
        if (token.isBlank()) { screen = "auth"; return }
        paymentLoading = true
        paymentMessage = "Membuat QRIS AutoGoPay…"
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    backendPost("payment_create", JSONObject().put("days", days), token)
                }
                paymentOrderId = result.optString("order_id")
                paymentQrUrl = result.optString("qr_url")
                paymentCheckoutUrl = result.optString("checkout_url")
                paymentAmount = result.optInt("amount", 1000 * days)
                selectedPlanDays = result.optInt("subscription_days", days)
                paymentMessage = "QRIS siap. Selesaikan pembayaran sebelum kedaluwarsa."
            } catch (e: Exception) {
                paymentMessage = e.message ?: "Gagal membuat pembayaran."
            } finally { paymentLoading = false }
        }
    }

    fun checkPayment() {
        if (paymentOrderId.isBlank()) {
            paymentMessage = "Buat pembayaran terlebih dahulu."
            return
        }
        paymentLoading = true
        paymentMessage = "Memeriksa status pembayaran…"
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    backendGet("payment_status", mapOf("order_id" to paymentOrderId), token)
                }
                val status = result.optString("status").uppercase()
                if (result.optBoolean("active", false) || status in listOf("PAID", "SETTLEMENT", "SUCCESS")) {
                    subscriptionActive = true
                    subscriptionExpiry = result.optString("expires_at", subscriptionExpiry)
                    showSubscriptionPrompt = false
                    paymentMessage = "Pembayaran berhasil. Langganan sudah aktif."
                    message = paymentMessage
                } else {
                    paymentMessage = "Pembayaran belum terkonfirmasi. Jika sudah membayar, tunggu sebentar lalu periksa lagi."
                }
            } catch (e: Exception) {
                paymentMessage = e.message ?: "Gagal memeriksa pembayaran."
            } finally { paymentLoading = false }
        }
    }

    LaunchedEffect(Unit) {
        if (token.isNotBlank()) {
            checkSubscriptionAndContinue()
            scope.launch { runCatching { withContext(Dispatchers.IO) { backendGet("plans", emptyMap(), token) } }.onSuccess { res ->
                val prices = res.optJSONObject("plans")
                if (prices != null) listOf(1,3,7,30).forEach { d -> if (prices.has(d.toString())) planPrices[d] = prices.optInt(d.toString(), planPrices[d] ?: 0) }
            } }
        }
    }
    DisposableEffect(Unit) { onDispose { stopPlayer() } }

    MaterialTheme(colorScheme = darkColorScheme(primary = Blue, background = Bg, surface = Panel, onBackground = White, onSurface = White)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                Row(
                    Modifier.fillMaxWidth().background(Bg).padding(start = 18.dp, end = 12.dp, top = 16.dp, bottom = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("DRAMAHUB", fontSize = 22.sp, fontWeight = FontWeight.Black, color = White, letterSpacing = 1.4.sp)
                        Text("Cerita seru, kapan saja", fontSize = 12.sp, color = Muted)
                    }
                    if (token.isNotBlank() && screen !in listOf("auth", "checking")) {
                        TextButton(onClick = { logout() }) { Text("Keluar", color = Blue) }
                    }
                }
                if (token.isNotBlank() && screen !in listOf("auth", "checking")) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            NavChip("🔥 Trending", section == "trending", Modifier.weight(1f)) { section = "trending"; load("trending", "Trending") }
                            NavChip("✨ Terbaru", section == "latest", Modifier.weight(1f)) { section = "latest"; load("latest", "Terbaru") }
                            NavChip("▦ Kategori", screen == "categories", Modifier.weight(1f)) { load("categories", "Kategori") }
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            NavChip("▶ Riwayat", screen == "history", Modifier.weight(1f)) {
                                screen = "history"
                                scope.launch { runCatching { withContext(Dispatchers.IO) { backendGet("payment_history", emptyMap(), token) } }.onSuccess { res ->
                                    val arr = res.optJSONArray("data") ?: JSONArray()
                                    paymentHistory = (0 until arr.length()).mapNotNull { i -> arr.optJSONObject(i)?.let { o -> PaymentEntry(o.optString("order_id"), o.optInt("amount"), o.optString("status"), o.optInt("subscription_days", 1), o.optString("created_at")) } }
                                } }
                            }
                            NavChip("👤 Profil", screen == "profile", Modifier.weight(1f)) { screen = "profile" }
                            NavChip("💎 Langganan", showSubscriptionPrompt, Modifier.weight(1f)) {
                                showSubscriptionPrompt = true
                                scope.launch { runCatching { withContext(Dispatchers.IO) { backendGet("plans", emptyMap(), token) } }.onSuccess { res ->
                                    val prices = res.optJSONObject("plans")
                                    if (prices != null) listOf(1,3,7,30).forEach { d -> if (prices.has(d.toString())) planPrices[d] = prices.optInt(d.toString(), planPrices[d] ?: 0) }
                                } }
                            }
                        }
                    }
                }
                when (screen) {
                    "auth" -> {
                        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
                            item {
                                Spacer(Modifier.height(28.dp))
                                Text(if (authMode == "login") "Selamat datang kembali" else "Buat akun DramaHub", color = White, fontSize = 28.sp, fontWeight = FontWeight.Black)
                                Text("Masuk untuk menikmati drama favoritmu.", color = Muted, modifier = Modifier.padding(top = 8.dp, bottom = 22.dp))
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                        Text(if (authMode == "login") "LOGIN" else "PENDAFTARAN", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                        OutlinedTextField(username, { username = it.filter { ch -> ch.isLetterOrDigit() || ch in "_.-" }.take(40) }, label = { Text("Username (min. 4 karakter)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                        OutlinedTextField(password, { password = it }, label = { Text("Password (min. 8 karakter)") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                                        Button(onClick = { submitAuth(authMode == "register") }, enabled = !loading, modifier = Modifier.fillMaxWidth()) {
                                            Text(if (loading) "Memproses…" else if (authMode == "login") "Masuk" else "Daftar akun")
                                        }
                                        TextButton(onClick = { authMode = if (authMode == "login") "register" else "login"; message = "" }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                                            Text(if (authMode == "login") "Belum punya akun? Daftar" else "Sudah punya akun? Masuk", color = Blue)
                                        }
                                    }
                                }
                                Text(message, color = if (message.contains("gagal", true) || message.contains("salah", true)) Color(0xFFFF8B8B) else Muted, modifier = Modifier.padding(top = 14.dp))
                                Text("Katalog bisa dijelajahi setelah login. Episode 1–5 gratis; episode berikutnya tersedia lewat paket langganan.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp))
                            }
                        }
                    }
                    "checking" -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = Blue)
                            Text("Memeriksa akun dan langganan…", color = Muted, modifier = Modifier.padding(top = 14.dp))
                        }
                    }
                    "subscription" -> LazyColumn(Modifier.fillMaxSize().padding(20.dp)) {
                        item {
                            Spacer(Modifier.height(34.dp))
                            Text("Langganan diperlukan", color = White, fontSize = 28.sp, fontWeight = FontWeight.Black)
                            Text("Akun ${accountLabel.ifBlank { username }} sudah masuk, tetapi belum memiliki langganan aktif.", color = Muted, modifier = Modifier.padding(top = 10.dp))
                            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().padding(top = 22.dp)) {
                                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text("Aktifkan akses DramaHub", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                    Text("Jelajahi katalog gratis dan beli paket langganan langsung lewat QRIS untuk membuka episode 6 ke atas.", color = Muted)
                                    Text("ID akun dapat dilihat di pesan pendaftaran/login yang diberikan backend atau panel admin.", color = Muted, fontSize = 12.sp)
                                    Button(onClick = { checkSubscriptionAndContinue() }, modifier = Modifier.fillMaxWidth()) { Text("Periksa langganan lagi") }
                                    OutlinedButton(onClick = { logout() }, modifier = Modifier.fillMaxWidth()) { Text("Keluar") }
                                }
                            }
                            Text(message, color = Muted, modifier = Modifier.padding(top = 14.dp))
                        }
                    }
                    "profile" -> LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                        item {
                            Spacer(Modifier.height(14.dp))
                            Text("Profil saya", color = White, fontSize = 28.sp, fontWeight = FontWeight.Black)
                            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().padding(top = 16.dp)) {
                                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Text("👤  ${accountLabel.ifBlank { username }}", color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                    Text("Status: ${if (subscriptionActive) "Langganan aktif" else "Akun gratis"}", color = if (subscriptionActive) Blue else Muted)
                                    if (subscriptionExpiry.isNotBlank() && subscriptionExpiry != "null") Text("Aktif sampai: $subscriptionExpiry", color = Muted)
                                    Button(onClick = { checkSubscriptionAndContinue() }, modifier = Modifier.fillMaxWidth()) { Text("Periksa status langganan") }
                                    OutlinedButton(onClick = { showSubscriptionPrompt = true }, modifier = Modifier.fillMaxWidth()) { Text("Beli / perpanjang langganan") }
                                    OutlinedButton(onClick = { screen = "history" }, modifier = Modifier.fillMaxWidth()) { Text("Riwayat tontonan") }
                                    OutlinedButton(onClick = { logout() }, modifier = Modifier.fillMaxWidth()) { Text("Keluar akun") }
                                }
                            }
                        }
                    }
                    "history" -> LazyColumn(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
                        item {
                            Spacer(Modifier.height(14.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Riwayat tontonan", color = White, fontSize = 26.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                                TextButton(onClick = { watchHistory = emptyList(); prefs.edit().remove("watch_history").apply() }) { Text("Hapus", color = Blue) }
                            }
                        }
                        if (watchHistory.isEmpty()) item { Text("Belum ada tontonan. Pilih drama dan mulai menonton untuk mengisi riwayat.", color = Muted, modifier = Modifier.padding(12.dp)) }
                        items(watchHistory) { entry ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable {
                                selected = Drama(entry.id, entry.title, entry.cover)
                                load("detail:" + entry.id, "Detail")
                            }, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(15.dp)) {
                                Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                    AsyncImage(model = entry.cover, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.size(width = 62.dp, height = 82.dp).clip(RoundedCornerShape(9.dp)))
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(entry.title, color = White, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                        Text("Episode ${entry.episode}", color = Blue, modifier = Modifier.padding(top = 5.dp))
                                        Text(java.text.SimpleDateFormat("dd MMM yyyy, HH:mm", java.util.Locale("id", "ID")).format(java.util.Date(entry.time)), color = Muted, fontSize = 11.sp)
                                    }
                                    Text("Lanjut ›", color = Blue, fontSize = 12.sp)
                                }
                            }
                        }
                        item { Text("Riwayat pembayaran", color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 20.dp, bottom = 8.dp)) }
                        if (paymentHistory.isEmpty()) item { Text("Belum ada transaksi pembayaran.", color = Muted, modifier = Modifier.padding(bottom = 20.dp)) }
                        items(paymentHistory) { payment ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(13.dp)) {
                                Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(payment.order, color = White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text("${payment.days} hari · Rp${"%,d".format(java.util.Locale("id", "ID"), payment.amount)}", color = Muted, fontSize = 12.sp)
                                        Text(payment.created, color = Muted, fontSize = 11.sp)
                                    }
                                    Text(payment.status, color = if (payment.status.equals("PAID", true)) Blue else Muted, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                    "categories" -> LazyColumn(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
                        item { Text(message, color = Muted, modifier = Modifier.padding(8.dp)) }
                        items(categories) { c ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(15.dp)) {
                                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text("▦", fontSize = 22.sp, color = Blue); Spacer(Modifier.width(12.dp))
                                    Column { Text(c.name, color = White, fontWeight = FontWeight.SemiBold); Text("Kategori tersedia dari provider", color = Muted, fontSize = 12.sp) }
                                }
                            }
                        }
                    }
                    "detail" -> {
                        val d = detailJson
                        if (d == null) Text("Detail belum tersedia", color = Muted, modifier = Modifier.padding(20.dp))
                        else LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                            item {
                                Row(Modifier.padding(top = 6.dp, bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text("‹", fontSize = 32.sp, color = Blue, modifier = Modifier.clickable { stopPlayer(); screen = "home" }.padding(end = 12.dp))
                                    Text("Detail drama", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = White)
                                }
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(14.dp)) {
                                        Row(verticalAlignment = Alignment.Top) {
                                            AsyncImage(model = d.optString("cover", selected?.cover), contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.width(116.dp).height(160.dp).clip(RoundedCornerShape(13.dp)))
                                            Spacer(Modifier.width(13.dp))
                                            Column(Modifier.weight(1f)) {
                                                Text(d.optString("title", selected?.title ?: "Drama"), color = White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                                                Text(d.optString("status", "Drama pendek"), color = Blue, fontSize = 12.sp, modifier = Modifier.padding(top = 7.dp))
                                                Text("${d.optString("total_episodes", d.optString("chapters", "-"))} episode", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 7.dp))
                                                Text(d.optString("author", ""), color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp), maxLines = 2, overflow = TextOverflow.Ellipsis)
                                            }
                                        }
                                        Text("SINOPSIS", fontSize = 11.sp, color = Blue, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, modifier = Modifier.padding(top = 16.dp))
                                        Text(d.optString("synopsis", "Sinopsis belum tersedia."), color = Muted, fontSize = 13.sp, lineHeight = 20.sp, modifier = Modifier.padding(top = 5.dp))
                                    }
                                }
                                Spacer(Modifier.height(14.dp))
                                if (videoUrl.isNotBlank() && player != null) {
                                    Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(16.dp)).background(Color.Black)) {
                                        AndroidView(factory = { ctx -> PlayerView(ctx).apply { useController = true } },
                                            update = { it.player = player }, modifier = Modifier.fillMaxSize())
                                        Surface(
                                            color = Color(0xCC101827),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.align(Alignment.TopEnd).padding(8.dp).clickable { showFullscreenPlayer = true }
                                        ) {
                                            Text("⛶  Layar penuh", color = White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp))
                                        }
                                    }
                                    Text("Episode $selectedEpisode", color = White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp, bottom = 8.dp))
                                } else if (videoLoading) {
                                    LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 12.dp))
                                    Text("Menyiapkan episode $selectedEpisode…", color = Muted, fontSize = 13.sp)
                                }
                                if (videoError.isNotBlank()) Text(videoError, color = Color(0xFFFF8B8B), fontSize = 13.sp, modifier = Modifier.padding(vertical = 8.dp))
                                Text("PILIH EPISODE", color = White, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 14.dp, bottom = 10.dp))
                            }
                            val countRaw = d.optInt("total_episodes", d.optInt("episode_count", d.optInt("chapters", 0)))
                            val count = if (countRaw > 0) countRaw else d.optJSONArray("chapters")?.length() ?: d.optJSONArray("episodes")?.length() ?: 0
                            if (count > 0) {
                                items((1..count.coerceAtMost(500)).toList().chunked(3)) { row ->
                                    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        row.forEach { ep ->
                                            Button(onClick = { playEpisode(ep) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = if (ep == selectedEpisode) Blue else Panel2, contentColor = White), shape = RoundedCornerShape(12.dp)) { Text("▶  $ep", fontSize = 13.sp) }
                                        }
                                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                                    }
                                }
                            } else item { Text("Jumlah episode tidak ditemukan dari data detail.", color = Muted, fontSize = 13.sp) }
                            item { Spacer(Modifier.height(24.dp)) }
                        }
                    }
                    else -> Column(Modifier.fillMaxSize()) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("Cari judul drama…") }, singleLine = true, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp))
                            Spacer(Modifier.width(8.dp))
                            Button(onClick = { if (query.isNotBlank()) { section = "search"; load("search:" + query, "Hasil pencarian") } }, shape = RoundedCornerShape(13.dp)) { Text("Cari") }
                        }
                        Text(message, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp))
                        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
                        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
                            items(dramas) { drama ->
                                Card(Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable {
                                    selected = drama
                                    load("detail:" + drama.id, "Detail")
                                }, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(17.dp)) {
                                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.Top) {
                                        AsyncImage(model = drama.cover, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.width(100.dp).height(137.dp).clip(RoundedCornerShape(12.dp)))
                                        Spacer(Modifier.width(12.dp))
                                        Column(Modifier.weight(1f).padding(top = 4.dp)) {
                                            Text(drama.title, color = White, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                            Text("${drama.status.ifBlank { "Drama pendek" }} ${if (drama.episodes.isNotBlank()) "· ${drama.episodes} eps" else ""}", color = Blue, fontSize = 12.sp, modifier = Modifier.padding(top = 7.dp))
                                            Text(drama.synopsis.ifBlank { drama.author }.ifBlank { "Buka untuk melihat detail dan episode." }, color = Muted, fontSize = 12.sp, maxLines = 3, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp), lineHeight = 17.sp)
                                            Text("LIHAT DRAMA  ›", color = Blue, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                                        }
                                    }
                                }
                            }
                            if (!loading && dramas.isEmpty()) item {
                                Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("🎬", fontSize = 42.sp)
                                    Text("Belum ada drama", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = White, modifier = Modifier.padding(top = 8.dp))
                                    Text(message, color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                                    Button(onClick = { load("trending", "Trending") }, modifier = Modifier.padding(top = 14.dp)) { Text("Muat ulang") }
                                }
                            }
                        }
                    }
                }
            }
            if (showSubscriptionPrompt) {
                AlertDialog(
                    onDismissRequest = { showSubscriptionPrompt = false },
                    title = { Text("Langganan diperlukan") },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Episode 1–5 gratis. Episode 6 dan seterusnya perlu langganan. Pilih paket, bayar melalui QRIS, lalu periksa status pembayaran.", color = Muted)
                            Text("Pilih masa aktif", color = White, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                                listOf(1, 3, 7, 30).forEach { days ->
                                    FilterChip(selected = selectedPlanDays == days, onClick = { selectedPlanDays = days; if (paymentOrderId.isNotBlank()) { paymentOrderId = ""; paymentQrUrl = ""; paymentCheckoutUrl = ""; paymentAmount = (planPrices[days] ?: 1000); paymentMessage = "Paket berubah. Buat QR baru untuk paket ini." } }, label = { Text("${days}h") })
                                }
                            }
                            Text("Harga: Rp${"%,d".format(java.util.Locale("id", "ID"), if (paymentOrderId.isBlank()) (planPrices[selectedPlanDays] ?: paymentAmount) else paymentAmount)} · paket ${selectedPlanDays} hari", color = White, fontWeight = FontWeight.Bold)
                            if (paymentQrUrl.isNotBlank()) {
                                AsyncImage(model = paymentQrUrl, contentDescription = "Tekan untuk memperbesar QRIS",
                                    modifier = Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(12.dp)).clickable { showQrZoom = true },
                                    contentScale = ContentScale.Fit)
                                Text("Ketuk QR untuk memperbesar", color = Blue, fontSize = 11.sp)
                                Text("Order: $paymentOrderId", color = Muted, fontSize = 11.sp)
                            }
                            if (paymentMessage.isNotBlank()) Text(paymentMessage, color = if (paymentMessage.contains("berhasil", true)) Blue else Muted, fontSize = 12.sp)
                        }
                    },
                    confirmButton = {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            TextButton(onClick = { checkPayment() }, enabled = !paymentLoading && paymentOrderId.isNotBlank()) { Text("Cek pembayaran") }
                            TextButton(onClick = { createPayment(selectedPlanDays) }, enabled = !paymentLoading) { Text(if (paymentOrderId.isBlank()) "Beli sekarang" else "Buat QR baru") }
                        }
                    },
                    dismissButton = {
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            TextButton(onClick = {
                                val orderToCancel = paymentOrderId
                                if (orderToCancel.isNotBlank()) scope.launch {
                                    runCatching { withContext(Dispatchers.IO) { backendPost("payment_cancel", JSONObject().put("order_id", orderToCancel), token) } }
                                }
                                paymentOrderId = ""; paymentQrUrl = ""; paymentCheckoutUrl = ""; paymentAmount = (planPrices[selectedPlanDays] ?: 1000); paymentMessage = "Pembayaran ditutup. Jika sudah membayar, tekan periksa status sebelum membuat transaksi baru."; showSubscriptionPrompt = false
                            }) { Text("Batalkan") }
                            TextButton(onClick = { showSubscriptionPrompt = false }) { Text("Tutup") }
                        }
                    },
                    containerColor = Panel,
                    titleContentColor = White,
                    textContentColor = Muted
                )
            }
            if (showQrZoom && paymentQrUrl.isNotBlank()) {
                Dialog(onDismissRequest = { showQrZoom = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
                    Box(Modifier.fillMaxSize().background(Color(0xF5080D19)).clickable { showQrZoom = false }, contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth().padding(20.dp)) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text("QRIS AutoGoPay", color = White, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
                                TextButton(onClick = { showQrZoom = false }) { Text("✕ Tutup", color = Blue) }
                            }
                            AsyncImage(model = paymentQrUrl, contentDescription = "QRIS diperbesar", contentScale = ContentScale.Fit,
                                modifier = Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(12.dp)).background(Color.White).padding(8.dp))
                            Text("Order: $paymentOrderId", color = Muted, modifier = Modifier.padding(top = 12.dp))
                            Button(onClick = { showQrZoom = false }, modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) { Text("Tutup QR") }
                        }
                    }
                }
            }
            if (showFullscreenPlayer && player != null) {
                Dialog(
                    onDismissRequest = { showFullscreenPlayer = false },
                    properties = DialogProperties(usePlatformDefaultWidth = false)
                ) {
                    Box(Modifier.fillMaxSize().background(Color.Black)) {
                        AndroidView(factory = { ctx -> PlayerView(ctx).apply { useController = true; resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT } },
                            update = { it.player = player }, modifier = Modifier.fillMaxSize())
                        Surface(
                            color = Color(0xCC101827),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.align(Alignment.TopEnd).padding(12.dp).clickable { showFullscreenPlayer = false }
                        ) {
                            Text("✕  Tutup", color = White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NavChip(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(color = if (selected) Blue else Panel2, shape = RoundedCornerShape(12.dp), modifier = modifier.clickable(onClick = onClick)) {
        Text(label, color = if (selected) Bg else White, fontWeight = FontWeight.SemiBold, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp))
    }
}

private fun loadWatchHistory(raw: String): List<WatchEntry> = runCatching {
    val arr = JSONArray(raw)
    (0 until arr.length()).mapNotNull { i -> arr.optJSONObject(i)?.let { o ->
        WatchEntry(o.optString("id"), o.optString("title", "Drama"), o.optString("cover"), o.optInt("episode"), o.optLong("time"))
    } }
}.getOrDefault(emptyList())

private fun watchHistoryToJson(items: List<WatchEntry>): String {
    val arr = JSONArray()
    items.forEach { e -> arr.put(JSONObject().put("id", e.id).put("title", e.title).put("cover", e.cover).put("episode", e.episode).put("time", e.time)) }
    return arr.toString()
}

private fun getArray(json: JSONObject): JSONArray {
    for (key in listOf("data", "items", "results", "categories")) json.optJSONArray(key)?.let { return it }
    json.optJSONObject("data")?.let { d -> for (key in listOf("data", "items", "results", "categories")) d.optJSONArray(key)?.let { return it } }
    return JSONArray()
}

private fun normalizeDetail(source: JSONObject): JSONObject {
    val out = JSONObject(source.toString())
    if (!out.has("title")) out.put("title", source.optString("name", source.optString("bookName", "Drama")))
    if (!out.has("cover")) out.put("cover", source.optString("poster", source.optString("cover_url", source.optString("image", ""))))
    if (!out.has("synopsis")) out.put("synopsis", source.optString("description", source.optString("desc", "")))
    if (!out.has("total_episodes")) out.put("total_episodes", source.optInt("episode_count", source.optInt("chapters", 0)))
    if (out.opt("total_episodes") is JSONObject || out.opt("total_episodes") is JSONArray) {
        val eps = out.optJSONArray("chapters") ?: out.optJSONArray("episodes")
        out.put("total_episodes", eps?.length() ?: 0)
    }
    return out
}

private fun collectVideoUrls(obj: Any?, out: MutableList<String> = mutableListOf()): List<String> {
    when (obj) {
        is JSONObject -> {
            val keys = obj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val v = obj.opt(k)
                if (v is String && v.startsWith("http", true) &&
                    (k.contains("video", true) || k.contains("stream", true) || k.contains("play", true) ||
                     k.contains("url", true) || k.contains("source", true) || k == "src" || k == "link" ||
                     v.contains(".m3u8", true) || v.contains(".mp4", true) || v.contains(".mpd", true))) {
                    if (!k.contains("subtitle", true) && !k.contains("poster", true) && !k.contains("image", true)) out.add(v)
                } else collectVideoUrls(v, out)
            }
        }
        is JSONArray -> for (i in 0 until obj.length()) collectVideoUrls(obj.opt(i), out)
    }
    return out.distinct()
}

private fun backendGet(action: String, params: Map<String, String>, token: String): JSONObject {
    val all = linkedMapOf("action" to action)
    all.putAll(params)
    val query = all.entries.joinToString("&") { (k, v) -> enc(k) + "=" + enc(v) }
    val headers = mutableMapOf<String, String>()
    if (token.isNotBlank()) headers["Authorization"] = "Bearer $token"
    return requestBackend(API_BASE + "?" + query, "GET", headers, null)
}

private fun backendPost(action: String, body: JSONObject, token: String = ""): JSONObject {
    val headers = mutableMapOf("Content-Type" to "application/json")
    if (token.isNotBlank()) headers["Authorization"] = "Bearer $token"
    return requestBackend(API_BASE + "?action=" + enc(action), "POST", headers, body.toString())
}

private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8").replace("+", "%20")

private fun requestBackend(url: String, method: String, headers: Map<String, String>, body: String?): JSONObject {
    val connection = URL(url).openConnection() as HttpURLConnection
    connection.requestMethod = method
    connection.connectTimeout = 15000
    connection.readTimeout = 30000
    connection.setRequestProperty("Accept", "application/json")
    headers.forEach { (k, v) -> connection.setRequestProperty(k, v) }
    if (body != null) {
        connection.doOutput = true
        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
    }
    try {
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val raw = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        val result = runCatching { JSONObject(raw) }.getOrElse { JSONObject().put("ok", false).put("error", "Respons backend tidak valid (HTTP $code).") }
        if (code !in 200..299 || !result.optBoolean("ok", true)) {
            val detail = result.optString("error", "Permintaan gagal (HTTP $code).")
            val codeName = result.optString("code")
            throw IllegalStateException(if (codeName.isNotBlank()) "$detail [$codeName]" else detail)
        }
        return result
    } finally { connection.disconnect() }
}
