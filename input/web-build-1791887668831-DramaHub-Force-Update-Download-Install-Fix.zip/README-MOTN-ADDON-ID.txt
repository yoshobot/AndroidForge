DramaHub Android — update sementara

Menu Film dan halaman katalog Movie of the Night disembunyikan/dihapus dari navigasi aplikasi. Beranda, Video/QuickPlay, Kategori, Nobar, Profil, dan fitur lain dipertahankan. Backend tidak perlu diubah untuk update UI ini.

Catatan: build Android belum diverifikasi di lingkungan ini; silakan build di AndroidForge dan kirim log jika ada error.
