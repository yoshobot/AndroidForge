package com.dramahub.app

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.widget.Toast

class ApkDownloadReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != DownloadManager.ACTION_DOWNLOAD_COMPLETE) return
        val completedId = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L)
        val prefs = context.getSharedPreferences("dramahub_update", Context.MODE_PRIVATE)
        val expectedId = prefs.getLong("pending_download_id", -2L)
        if (completedId < 0L || completedId != expectedId) return

        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val query = DownloadManager.Query().setFilterById(completedId)
        var status = -1
        var reason = 0
        manager.query(query).use { cursor ->
            if (cursor.moveToFirst()) {
                status = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                reason = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
            }
        }

        if (status != DownloadManager.STATUS_SUCCESSFUL) {
            prefs.edit().remove("pending_download_id").apply()
            Toast.makeText(context, "Unduhan APK gagal (kode $reason). Coba lagi.", Toast.LENGTH_LONG).show()
            return
        }

        val apkUri: Uri = manager.getUriForDownloadedFile(completedId) ?: run {
            prefs.edit().remove("pending_download_id").apply()
            Toast.makeText(context, "File APK tidak ditemukan setelah diunduh.", Toast.LENGTH_LONG).show()
            return
        }
        prefs.edit().remove("pending_download_id").apply()
        val installIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(apkUri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(installIntent)
        } catch (e: Exception) {
            Toast.makeText(context, "Tidak dapat membuka pemasang APK. Buka unduhan dan pasang secara manual.", Toast.LENGTH_LONG).show()
        }
    }
}
