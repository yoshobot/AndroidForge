DramaHub Android — Video Loading/Error Fix

Perbaikan pada MainActivity.kt:
- Mengabaikan hasil request video lama setelah pengguna menggeser ke drama lain.
- Mencegah request lama mengubah videoError atau mematikan indikator loading milik request terbaru.
- Pesan error dan tombol Coba lagi dipindahkan ke lapisan depan agar tidak tertutup gradient poster.
- Pesan URL video kosong dibuat lebih jelas.

File utama: app/src/main/java/com/dramahub/app/MainActivity.kt

Catatan: source telah diperbarui, tetapi APK belum dikompilasi atau diuji di perangkat pada lingkungan ini. Build lewat AndroidForge lalu uji tab Video, geser beberapa drama dengan cepat, dan coba ulang jika URL video tidak tersedia.
