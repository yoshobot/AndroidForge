DRAMAHUB - PERBAIKAN APP ID ADMOB

Perubahan pada source ini:
- AndroidManifest.xml memakai App ID AdMob DramaHub: ca-app-pub-2278220353789760~7345530095
- Versi aplikasi dinaikkan menjadi 1.3.2 (versionCode 6).
- Integrasi SDK iklan yang sudah ada dipertahankan.
- Aplikasi membaca status dan Interstitial Ad Unit ID dari https://dramahubx.my.id/app-config.php.
- Interstitial dipanggil setiap 3 pemilihan episode untuk pengguna non-Premium; bukan iklan yang selalu muncul di halaman utama.

PENTING:
1. Import ZIP ini ke AndroidForge dan build APK BARU. APK lama tidak berubah otomatis.
2. Instal APK baru untuk pengujian.
3. Pastikan app-config.php mengembalikan JSON dengan ads.enabled=true, ads.configured=true, dan ads.interstitial_id berisi ID unit Interstitial asli.
4. AdMob dapat membutuhkan waktu sampai sekitar 1 jam setelah unit dibuat untuk mulai menayangkan iklan. Gunakan iklan uji saat pengujian; jangan klik iklan produksi sendiri.
5. ZIP ini adalah source, bukan APK hasil build. Build belum dapat diverifikasi di lingkungan ini karena Gradle tidak tersedia.

Catatan: Banner dan Rewarded ID sudah tersimpan di server, tetapi source ini belum mengimplementasikan tampilan Banner/Rewarded. Perubahan ini menargetkan agar Interstitial yang memang sudah ada bisa memakai App ID dan unit iklan produksi dengan benar.
