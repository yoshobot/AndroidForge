DRAMAHUB NOBAR / WATCH PARTY

AndroidForge source project. Import this ZIP and build a new APK.
Features:
- Private room with six-character invite code
- Host-only play/pause, seek ±10 seconds and episode selection
- Room state polling every 2 seconds
- Playback position correction when member drift exceeds about 2.8 seconds
- Chat and emoji reactions
- Uses existing DramaHub login token and API endpoint

SERVER INSTALL:
1. Upload nobar.php to public_html/nobar.php (same directory as index.php and config.php).
2. Import nobar-migration.sql into the SAME MySQL database DramaHub already uses.
3. Confirm https://dramahubx.my.id/nobar.php?action=health returns JSON.
4. Import this ZIP in AndroidForge and build a new APK.
5. Install the new APK on at least two devices and login using two separate accounts.

IMPORTANT:
- All members must have a valid DramaHub login.
- Only the room host can control playback.
- The server stores room state in MySQL; the Android app polls every 2 seconds because shared PHP hosting does not guarantee WebSocket support.
- Source syntax was reviewed and PHP passed php -l. Gradle/Android build and live two-device test were not available in this environment; test in AndroidForge before production.
