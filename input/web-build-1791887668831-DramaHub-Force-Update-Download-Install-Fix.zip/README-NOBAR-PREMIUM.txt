DramaHub Android - Nobar Premium

Ini source project Android lengkap, bukan APK.

Fitur:
- Halaman utama Nobar tidak langsung membuat ruang.
- Nobar dibatasi untuk akun dengan subscriptionActive=true.
- Pengguna non-Premium diarahkan ke halaman subscription.
- Akses create/join juga dicek di sisi Android.
- UI thread fix dan layout kontrol dari source Nobar UI Thread Fix dipertahankan.

File utama:
app/src/main/java/com/dramahub/app/MainActivity.kt

Penting:
Backend nobar.php juga wajib memvalidasi langganan aktif pada endpoint create/join/command/chat. Pembatasan di APK saja tidak aman karena APK bisa dimodifikasi.
Build belum diuji dengan Gradle di lingkungan ini. Impor ZIP ke AndroidForge lalu build Debug dan kirim log jika masih gagal.
