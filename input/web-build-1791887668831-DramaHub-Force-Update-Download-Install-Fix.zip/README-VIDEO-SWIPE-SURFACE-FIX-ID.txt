DramaHub Android — Video Hitam / Audio Tetap Jalan setelah Swipe

Perubahan pada app/src/main/java/com/dramahub/app/MainActivity.kt:
- PlayerView di tab Video memakai TextureView agar surface lebih stabil ketika VerticalPager mengganti halaman.
- Surface/player dilepas dari AndroidView lama saat view di-dispose.
- Saat halaman drama berubah, player lama langsung dihentikan agar audio tidak terus berjalan di belakang poster.
- Request stream drama baru ditunda 220 ms sampai gesture swipe lebih stabil, mengurangi request/player berulang dan membuat scroll lebih halus.

Pemasangan:
1. Cadangkan source Android yang sekarang.
2. Import ZIP ini ke AndroidForge dan build APK baru.
3. Pasang APK baru, buka tab Video, geser beberapa drama ke atas/bawah dan periksa video serta audio.

Status verifikasi:
- Source telah diperbarui dan ZIP diperiksa.
- APK belum dikompilasi atau diuji pada perangkat di lingkungan ini. Jika AndroidForge gagal build, kirim AndroidForge-logs.zip terbaru.
