package store.zione.dramahub

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

private val Bg = Color(0xFF080D19)
private val Panel = Color(0xFF111B2D)
private val Panel2 = Color(0xFF18263D)
private val Blue = Color(0xFF42A5F5)
private val Muted = Color(0xFF9AA9C3)
private val White = Color(0xFFF4F7FF)

data class Drama(val id:String, val title:String, val cover:String="", val synopsis:String="", val status:String="", val author:String="", val episodes:String="")
data class DramaCategory(val id:String, val name:String)
data class Episode(val number:Int, val title:String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8,13,25)
        window.navigationBarColor = android.graphics.Color.rgb(8,13,25)
        setContent { DramaHubApp(this) }
    }
}

@Composable
fun DramaHubApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("dramahub", Context.MODE_PRIVATE) }
    var apiSecret by remember { mutableStateOf(prefs.getString("quickplay_secret", "") ?: "") }
    var editSecret by remember { mutableStateOf(apiSecret) }
    var category by remember { mutableStateOf(prefs.getString("category_p", "freereels") ?: "freereels") }
    var editCategory by remember { mutableStateOf(category) }
    var screen by remember { mutableStateOf("home") }
    var section by remember { mutableStateOf("trending") }
    var query by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("Temukan cerita yang kamu suka.") }
    var loading by remember { mutableStateOf(false) }
    var dramas by remember { mutableStateOf(listOf<Drama>()) }
    var categories by remember { mutableStateOf(listOf<DramaCategory>()) }
    var selected by remember { mutableStateOf<Drama?>(null) }
    var detailJson by remember { mutableStateOf<JSONObject?>(null) }
    var selectedEpisode by remember { mutableStateOf(0) }
    var videoUrl by remember { mutableStateOf("") }
    var videoLoading by remember { mutableStateOf(false) }
    var videoError by remember { mutableStateOf("") }
    var adminPin by remember { mutableStateOf(prefs.getString("admin_pin", "") ?: "") }
    var pinInput by remember { mutableStateOf("") }
    var adminUnlocked by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    var player by remember { mutableStateOf<ExoPlayer?>(null) }

    fun stopPlayer() { player?.release(); player = null }
    fun load(path: String, label: String) {
        if (apiSecret.isBlank()) { editSecret=apiSecret; editCategory=category; screen = "admin"; message = "Masukkan API secret QuickPlay."; return }
        loading = true; message = "Mengambil data dari QuickPlay…"
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    val endpoint = when {
                        path.startsWith("trending") || path.startsWith("latest") -> "home"
                        path == "categories" -> "categories"
                        path.startsWith("search:") -> "search"
                        path.startsWith("detail:") -> "detail"
                        else -> throw IllegalArgumentException("Menu tidak dikenal")
                    }
                    val params = linkedMapOf<String, String>()
                    when(endpoint) {
                        "home" -> { params["category_p"]=category; params["lang"]="id"; params["page"]="1" }
                        "search" -> { params["category_p"]=category; params["lang"]="id"; params["page"]="1"; params["limit"]="20"; params["q"]=path.substringAfter("search:") }
                        "detail" -> {
                            val rawId=path.substringAfter("detail:")
                            val pieces=rawId.split("~", limit=2)
                            params["category_p"]=if(pieces.size==2) pieces[0] else category
                            params["id"]=if(pieces.size==2) pieces[1] else rawId
                            params["lang"]="id"
                        }
                    }
                    val apiPath=when(endpoint) { "home"->"/api/v2/home"; "categories"->"/api/v2/categories"; "search"->"/api/v2/search"; else->"/api/v2/detail" }
                    quickPlayRequest("https://api.quickplay.my.id",apiPath,params,apiSecret)
                }
                when {
                    path == "categories" -> {
                        val arr=getArray(result)
                        categories=(0 until arr.length()).mapNotNull { i -> arr.optJSONObject(i)?.let { o ->
                            val id=o.optString("name",o.optString("slug",o.optString("id")))
                            DramaCategory(id,o.optString("display_name",o.optString("name",o.optString("slug","Kategori"))))
                        }}
                        screen="categories"; message="${categories.size} kategori tersedia"
                    }
                    path.startsWith("detail:") -> {
                        val data=result.optJSONObject("data") ?: result
                        detailJson=normalizeQuickPlayDetail(data); screen="detail"; selectedEpisode=0; videoUrl=""; videoError=""
                        message="Pilih episode untuk mulai menonton"
                    }
                    else -> {
                        val arr=getArray(result)
                        dramas=(0 until arr.length()).mapNotNull { i -> arr.optJSONObject(i)?.let { o ->
                            val rawId=o.optString("id",o.optString("bookId",o.optString("drama_id")))
                            val finalId=if(rawId.isNotBlank() && !rawId.contains("~")) "$category~$rawId" else rawId
                            Drama(finalId,o.optString("title",o.optString("name",o.optString("bookName","Tanpa judul"))),
                                o.optString("cover",o.optString("poster",o.optString("cover_url",o.optString("image")))),
                                o.optString("synopsis",o.optString("description",o.optString("desc"))),o.optString("status"),o.optString("author"),
                                o.optString("chapters",o.optString("total_episodes",o.optString("episode_count"))))
                        }}
                        screen="home"; message="$label · ${dramas.size} judul"
                    }
                }
            } catch(e:Exception) {
                message="Gagal memuat: ${e.message ?: "periksa koneksi dan secret"}"
            } finally { loading=false }
        }
    }

    fun playEpisode(number:Int) {
        val d=detailJson ?: return
        if(number<1 || number>1000) return
        videoLoading=true; videoError=""; videoUrl=""; selectedEpisode=number; stopPlayer()
        scope.launch {
            try {
                val id=selected?.id ?: throw IllegalStateException("ID drama tidak tersedia")
                val parts=id.split("~",limit=2)
                val params=linkedMapOf("category_p" to (if(parts.size==2) parts[0] else category),
                    "id" to (if(parts.size==2) parts[1] else id), "chapterId" to number.toString(), "lang" to "id")
                val response=withContext(Dispatchers.IO) { quickPlayRequest("https://api.quickplay.my.id","/api/v2/video",params,apiSecret) }
                val data=response.optJSONObject("data") ?: response.optJSONObject("episode") ?: response
                val found=collectVideoUrls(data)
                val url=found.firstOrNull { it.endsWith(".m3u8",true) } ?: found.firstOrNull { it.endsWith(".mp4",true) } ?: found.firstOrNull()
                if(url.isNullOrBlank()) throw IllegalStateException("QuickPlay tidak mengembalikan URL video untuk episode ini.")
                videoUrl=url
                withContext(Dispatchers.Main) {
                    player=ExoPlayer.Builder(context).build().also { p ->
                        p.setMediaItem(MediaItem.fromUri(url)); p.prepare(); p.playWhenReady=true
                    }
                }
            } catch(e:Exception) { videoError=e.message ?: "Video gagal dimuat" }
            finally { videoLoading=false }
        }
    }

    DisposableEffect(Unit) { onDispose { stopPlayer() } }

    MaterialTheme(colorScheme=darkColorScheme(primary=Blue,background=Bg,surface=Panel,onBackground=White,onSurface=White)) {
        Surface(Modifier.fillMaxSize(), color=Bg) {
            Column {
                Row(Modifier.fillMaxWidth().background(Bg).padding(start=18.dp,end=12.dp,top=16.dp,bottom=12.dp), verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("DRAMAHUB",fontSize=22.sp,fontWeight=FontWeight.Black,color=White,letterSpacing=1.4.sp)
                        Text("Cerita seru, kapan saja",fontSize=12.sp,color=Muted)
                    }
                    Surface(color=Panel2,shape=RoundedCornerShape(14.dp),modifier=Modifier.size(44.dp).clickable {
                        editSecret=apiSecret; editCategory=category; pinInput=""; screen="admin"
                    }) { Box(contentAlignment=Alignment.Center) { Text("⚙",fontSize=22.sp,color=Blue) } }
                }
                if(screen !in listOf("admin","detail")) {
                    Row(Modifier.fillMaxWidth().padding(horizontal=12.dp, vertical=8.dp), horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                        NavChip("🔥 Trending",section=="trending") { section="trending"; load("trending","Trending") }
                        NavChip("✨ Terbaru",section=="latest") { section="latest"; load("latest","Terbaru") }
                        NavChip("▦ Kategori",screen=="categories") { load("categories","Kategori") }
                    }
                }
                when(screen) {
                    "admin" -> {
                        if(adminPin.isNotBlank() && !adminUnlocked) {
                            LazyColumn(Modifier.fillMaxSize().padding(20.dp)) {
                                item {
                                    Text("PANEL ADMIN",fontSize=22.sp,fontWeight=FontWeight.Black,color=White)
                                    Text("Masukkan PIN admin perangkat ini.",color=Muted,modifier=Modifier.padding(top=6.dp,bottom=18.dp))
                                    OutlinedTextField(pinInput,{pinInput=it},label={Text("PIN admin")},singleLine=true,modifier=Modifier.fillMaxWidth())
                                    Button(onClick={if(pinInput==adminPin) { adminUnlocked=true; pinInput="" } else message="PIN admin salah" },modifier=Modifier.fillMaxWidth().padding(top=12.dp)) { Text("Buka panel") }
                                    Text(message,color=Muted,modifier=Modifier.padding(top=10.dp))
                                    TextButton(onClick={screen="home"}) { Text("Kembali") }
                                }
                            }
                        } else {
                            LazyColumn(Modifier.fillMaxSize().padding(horizontal=18.dp)) {
                                item {
                                    Text("PANEL ADMIN",fontSize=22.sp,fontWeight=FontWeight.Black,color=White,modifier=Modifier.padding(top=12.dp))
                                    Text("Kelola koneksi provider dan pengaturan aplikasi.",color=Muted,modifier=Modifier.padding(top=4.dp,bottom=16.dp))
                                    Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(18.dp),modifier=Modifier.fillMaxWidth()) {
                                        Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
                                            Text("Koneksi QuickPlay",fontWeight=FontWeight.Bold,fontSize=17.sp,color=White)
                                            OutlinedTextField(editSecret,{editSecret=it},label={Text("API secret QuickPlay")},singleLine=true,modifier=Modifier.fillMaxWidth())
                                            OutlinedTextField(editCategory,{editCategory=it},label={Text("Kategori default (category_p)")},singleLine=true,modifier=Modifier.fillMaxWidth())
                                            Button(onClick={
                                                apiSecret=editSecret.trim(); category=editCategory.trim().ifBlank{"freereels"}
                                                prefs.edit().putString("quickplay_secret",apiSecret).putString("category_p",category).apply()
                                                message="Pengaturan berhasil disimpan"
                                            },modifier=Modifier.fillMaxWidth()) { Text("Simpan pengaturan") }
                                            Text("Provider: QuickPlay langsung · HTTPS",color=Muted,fontSize=12.sp)
                                        }
                                    }
                                    Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(18.dp),modifier=Modifier.fillMaxWidth().padding(top=12.dp)) {
                                        Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                                            Text("Keamanan admin",fontWeight=FontWeight.Bold,fontSize=17.sp,color=White)
                                            Text(if(adminPin.isBlank()) "Belum ada PIN admin. Buat PIN untuk membatasi akses ke halaman ini." else "PIN admin sudah dibuat di perangkat ini.",color=Muted,fontSize=13.sp)
                                            var newPin by remember { mutableStateOf("") }
                                            OutlinedTextField(newPin,{newPin=it.filter(Char::isDigit).take(8)},label={Text(if(adminPin.isBlank()) "Buat PIN (4–8 angka)" else "Ganti PIN admin")},singleLine=true,modifier=Modifier.fillMaxWidth())
                                            Button(onClick={
                                                if(newPin.length in 4..8) { adminPin=newPin; prefs.edit().putString("admin_pin",newPin).apply(); newPin=""; adminUnlocked=true; message="PIN admin tersimpan" }
                                                else message="PIN harus 4–8 angka"
                                            },modifier=Modifier.fillMaxWidth()) { Text("Simpan PIN") }
                                        }
                                    }
                                    Text("Catatan: PIN hanya mengunci panel pada perangkat ini. Untuk aplikasi publik, secret QuickPlay sebaiknya disimpan di backend, bukan APK.",color=Muted,fontSize=12.sp,modifier=Modifier.padding(vertical=14.dp))
                                    Text(message,color=Muted,fontSize=12.sp)
                                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                                        OutlinedButton(onClick={adminUnlocked=false;screen="home"},modifier=Modifier.weight(1f)) { Text("Kembali ke beranda") }
                                        Button(onClick={section="trending";screen="home";load("trending","Trending")},modifier=Modifier.weight(1f)) { Text("Tes koneksi") }
                                    }
                                }
                            }
                        }
                    }
                    "categories" -> LazyColumn(Modifier.fillMaxSize().padding(horizontal=14.dp)) {
                        item { Text(message,color=Muted,modifier=Modifier.padding(8.dp)) }
                        items(categories) { c ->
                            Card(Modifier.fillMaxWidth().padding(vertical=5.dp).clickable { category=c.id; prefs.edit().putString("category_p",category).apply(); section="trending";load("trending","Kategori ${c.name}") },colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(15.dp)) {
                                Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically) {
                                    Text("▦",fontSize=22.sp,color=Blue); Spacer(Modifier.width(12.dp))
                                    Column { Text(c.name,color=White,fontWeight=FontWeight.SemiBold); Text("Lihat drama",color=Muted,fontSize=12.sp) }
                                }
                            }
                        }
                    }
                    "detail" -> {
                        val d=detailJson
                        if(d==null) Text("Detail belum tersedia",color=Muted,modifier=Modifier.padding(20.dp))
                        else LazyColumn(Modifier.fillMaxSize().padding(horizontal=16.dp)) {
                            item {
                                Row(Modifier.padding(top=6.dp,bottom=14.dp),verticalAlignment=Alignment.CenterVertically) {
                                    Text("‹",fontSize=32.sp,color=Blue,modifier=Modifier.clickable { stopPlayer();screen="home" }.padding(end=12.dp))
                                    Text("Detail drama",fontSize=19.sp,fontWeight=FontWeight.Bold,color=White)
                                }
                                Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(20.dp),modifier=Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(14.dp)) {
                                        Row(verticalAlignment=Alignment.Top) {
                                            AsyncImage(model=d.optString("cover",selected?.cover),contentDescription=null,contentScale=ContentScale.Crop,modifier=Modifier.width(116.dp).height(160.dp).clip(RoundedCornerShape(13.dp)))
                                            Spacer(Modifier.width(13.dp))
                                            Column(Modifier.weight(1f)) {
                                                Text(d.optString("title",selected?.title ?: "Drama"),color=White,fontSize=19.sp,fontWeight=FontWeight.Bold)
                                                Text(d.optString("status","Drama pendek"),color=Blue,fontSize=12.sp,modifier=Modifier.padding(top=7.dp))
                                                Text("${d.optString("total_episodes",d.optString("chapters","-"))} episode",color=Muted,fontSize=12.sp,modifier=Modifier.padding(top=7.dp))
                                                Text(d.optString("author",""),color=Muted,fontSize=12.sp,modifier=Modifier.padding(top=5.dp),maxLines=2,overflow=TextOverflow.Ellipsis)
                                            }
                                        }
                                        Text("SINOPSIS",fontSize=11.sp,color=Blue,fontWeight=FontWeight.Bold,letterSpacing=1.sp,modifier=Modifier.padding(top=16.dp))
                                        Text(d.optString("synopsis","Sinopsis belum tersedia."),color=Muted,fontSize=13.sp,lineHeight=20.sp,modifier=Modifier.padding(top=5.dp))
                                    }
                                }
                                Spacer(Modifier.height(14.dp))
                                if(videoUrl.isNotBlank() && player!=null) {
                                    AndroidView(factory={ ctx -> PlayerView(ctx).apply { this.player=player; useController=true } },
                                        update={ it.player=player },modifier=Modifier.fillMaxWidth().aspectRatio(16f/9f).clip(RoundedCornerShape(16.dp)))
                                    Text("Episode $selectedEpisode",color=White,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=10.dp,bottom=8.dp))
                                } else if(videoLoading) {
                                    LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical=12.dp))
                                    Text("Menyiapkan episode $selectedEpisode…",color=Muted,fontSize=13.sp)
                                }
                                if(videoError.isNotBlank()) Text(videoError,color=Color(0xFFFF8B8B),fontSize=13.sp,modifier=Modifier.padding(vertical=8.dp))
                                Text("PILIH EPISODE",color=White,fontSize=15.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=14.dp,bottom=10.dp))
                            }
                            val countRaw=d.optInt("total_episodes",d.optInt("episode_count",d.optInt("chapters",0)))
                            val count= if(countRaw>0) countRaw else d.optJSONArray("chapters")?.length() ?: d.optJSONArray("episodes")?.length() ?: 0
                            if(count>0) {
                                items((1..count.coerceAtMost(500)).toList().chunked(3)) { row ->
                                    Row(Modifier.fillMaxWidth().padding(bottom=8.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                                        row.forEach { ep ->
                                            Button(onClick={playEpisode(ep)},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=if(ep==selectedEpisode) Blue else Panel2,contentColor=White),shape=RoundedCornerShape(12.dp)) { Text("▶  $ep",fontSize=13.sp) }
                                        }
                                        repeat(3-row.size) { Spacer(Modifier.weight(1f)) }
                                    }
                                }
                            } else item { Text("Jumlah episode tidak ditemukan dari data detail.",color=Muted,fontSize=13.sp) }
                            item { Spacer(Modifier.height(24.dp)) }
                        }
                    }
                    else -> Column(Modifier.fillMaxSize()) {
                        Row(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=5.dp),verticalAlignment=Alignment.CenterVertically) {
                            OutlinedTextField(value=query,onValueChange={query=it},label={Text("Cari judul drama…")},singleLine=true,modifier=Modifier.weight(1f),shape=RoundedCornerShape(14.dp))
                            Spacer(Modifier.width(8.dp))
                            Button(onClick={if(query.isNotBlank()) { section="search"; load("search:"+query,"Hasil pencarian") }},shape=RoundedCornerShape(13.dp)) { Text("Cari") }
                        }
                        Text(message,color=Muted,fontSize=12.sp,modifier=Modifier.padding(horizontal=16.dp,vertical=9.dp))
                        if(loading) LinearProgressIndicator(Modifier.fillMaxWidth())
                        LazyColumn(Modifier.fillMaxSize().padding(horizontal=12.dp)) {
                            items(dramas) { drama ->
                                Card(Modifier.fillMaxWidth().padding(vertical=6.dp).clickable {
                                    selected=drama; load("detail:"+drama.id,"Detail")
                                },colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(17.dp)) {
                                    Row(Modifier.padding(10.dp),verticalAlignment=Alignment.Top) {
                                        AsyncImage(model=drama.cover,contentDescription=null,contentScale=ContentScale.Crop,modifier=Modifier.width(100.dp).height(137.dp).clip(RoundedCornerShape(12.dp)))
                                        Spacer(Modifier.width(12.dp))
                                        Column(Modifier.weight(1f).padding(top=4.dp)) {
                                            Text(drama.title,color=White,fontWeight=FontWeight.Bold,fontSize=16.sp,maxLines=2,overflow=TextOverflow.Ellipsis)
                                            Text("${drama.status.ifBlank{"Drama pendek"}} ${if(drama.episodes.isNotBlank()) "· ${drama.episodes} eps" else ""}",color=Blue,fontSize=12.sp,modifier=Modifier.padding(top=7.dp))
                                            Text(drama.synopsis.ifBlank{drama.author}.ifBlank{"Buka untuk melihat detail dan episode."},color=Muted,fontSize=12.sp,maxLines=3,overflow=TextOverflow.Ellipsis,modifier=Modifier.padding(top=8.dp),lineHeight=17.sp)
                                            Text("LIHAT DRAMA  ›",color=Blue,fontSize=10.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=8.dp))
                                        }
                                    }
                                }
                            }
                            if(!loading && dramas.isEmpty()) item {
                                Column(Modifier.fillMaxWidth().padding(28.dp),horizontalAlignment=Alignment.CenterHorizontally) {
                                    Text("🎬",fontSize=42.sp); Text("Belum ada drama",fontSize=18.sp,fontWeight=FontWeight.Bold,color=White,modifier=Modifier.padding(top=8.dp))
                                    Text("Buka panel admin untuk mengisi secret QuickPlay, lalu tes koneksi.",color=Muted,fontSize=13.sp,modifier=Modifier.padding(top=6.dp))
                                    Button(onClick={editSecret=apiSecret;editCategory=category;screen="admin"},modifier=Modifier.padding(top=14.dp)) { Text("Buka panel admin") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NavChip(label:String,selected:Boolean,onClick:()->Unit) {
    Surface(color=if(selected) Blue else Panel2,shape=RoundedCornerShape(12.dp),modifier=Modifier.clickable(onClick=onClick)) {
        Text(label,color=if(selected) Bg else White,fontWeight=FontWeight.SemiBold,fontSize=11.sp,modifier=Modifier.padding(horizontal=12.dp,vertical=10.dp))
    }
}
private fun getArray(json:JSONObject):JSONArray {
    for(key in listOf("data","items","results","categories")) json.optJSONArray(key)?.let{return it}
    json.optJSONObject("data")?.let { d -> for(key in listOf("data","items","results","categories")) d.optJSONArray(key)?.let{return it} }
    return JSONArray()
}
private fun normalizeQuickPlayDetail(source:JSONObject):JSONObject {
    val out=JSONObject(source.toString())
    if(!out.has("title")) out.put("title",source.optString("name",source.optString("bookName","Drama")))
    if(!out.has("cover")) out.put("cover",source.optString("poster",source.optString("cover_url",source.optString("image",""))))
    if(!out.has("synopsis")) out.put("synopsis",source.optString("description",source.optString("desc","")))
    if(!out.has("total_episodes")) out.put("total_episodes",source.optInt("episode_count",source.optInt("chapters",0)))
    if(out.opt("total_episodes") is JSONObject || out.opt("total_episodes") is JSONArray) {
        val eps=out.optJSONArray("chapters") ?: out.optJSONArray("episodes")
        out.put("total_episodes",eps?.length() ?: 0)
    }
    return out
}
private fun collectVideoUrls(obj:Any?,out:MutableList<String> = mutableListOf()):List<String> {
    when(obj) {
        is JSONObject -> {
            val keys=obj.keys()
            while(keys.hasNext()) { val k=keys.next(); val v=obj.opt(k)
                if(v is String && v.startsWith("http",true) && (k.contains("video",true)||k.contains("stream",true)||k.contains("play",true)||k.contains("url",true)||k.contains("source",true)||k=="src"||k=="link"||v.contains(".m3u8")||v.contains(".mp4")||v.contains(".mpd"))) {
                    if(!k.contains("subtitle",true) && !k.contains("poster",true) && !k.contains("image",true)) out.add(v)
                } else collectVideoUrls(v,out)
            }
        }
        is JSONArray -> for(i in 0 until obj.length()) collectVideoUrls(obj.opt(i),out)
    }
    return out.distinct()
}
private fun quickPlayRequest(base:String,path:String,params:Map<String,String>,secret:String):JSONObject {
    val query=params.entries.joinToString("&") { (k,v)-> URLEncoder.encode(k,"UTF-8")+"="+URLEncoder.encode(v,"UTF-8").replace("+","%20") }
    val pathQuery=path+if(query.isNotEmpty()) "?$query" else ""
    val timestamp=System.currentTimeMillis().toString()
    val mac=javax.crypto.Mac.getInstance("HmacSHA256")
    mac.init(javax.crypto.spec.SecretKeySpec(secret.toByteArray(Charsets.UTF_8),"HmacSHA256"))
    val signature=mac.doFinal("GET:$pathQuery:$timestamp".toByteArray(Charsets.UTF_8)).joinToString(""){"%02x".format(it)}
    return requestJson(base.trimEnd('/')+pathQuery,mapOf("X-Timestamp" to timestamp,"X-Signature" to signature))
}
private fun requestJson(url:String,headers:Map<String,String> = emptyMap()):JSONObject {
    val connection=URL(url).openConnection() as HttpURLConnection
    connection.requestMethod="GET"; connection.connectTimeout=12000; connection.readTimeout=25000
    connection.setRequestProperty("Accept","application/json"); headers.forEach{(k,v)->connection.setRequestProperty(k,v)}
    try {
        val code=connection.responseCode
        val stream=if(code in 200..299) connection.inputStream else connection.errorStream
        val body=stream.bufferedReader().use{it.readText()}
        if(code !in 200..299) throw IllegalStateException(runCatching{JSONObject(body).optString("message","HTTP $code")}.getOrDefault("HTTP $code"))
        val result=JSONObject(body)
        if(result.optBoolean("success",true)==false) throw IllegalStateException(result.optString("message","Provider gagal"))
        return result
    } finally { connection.disconnect() }
}
