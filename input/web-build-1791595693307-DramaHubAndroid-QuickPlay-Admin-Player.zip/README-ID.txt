DramaHub Android - QuickPlay Direct

Fitur:
- UI gelap modern untuk trending, drama terbaru, pencarian, kategori, detail.
- Memuat detail dan endpoint video episode langsung dari QuickPlay API.
- Pemutar video dalam aplikasi menggunakan AndroidX Media3/ExoPlayer.
- Panel Admin untuk mengatur QuickPlay API secret, kategori default, tes koneksi, dan PIN lokal panel admin.
- Tidak menggunakan endpoint bot, Pterodactyl, LocalTunnel, atau zione.store sebagai perantara.

Build:
1. Unggah ZIP ini sebagai source project ke AndroidForge.
2. Pilih Build APK.
3. Buka aplikasi, tekan ikon roda gigi / Panel Admin.
4. Masukkan API secret QuickPlay dan kategori default (biasanya freereels), lalu Simpan Pengaturan.
5. Tekan Tes Koneksi, kembali ke beranda, pilih drama, lalu pilih episode.

Catatan:
- PIN panel admin hanya pengunci lokal pada perangkat, bukan sistem autentikasi server.
- Secret API yang ditanam di APK bisa diekstrak. Untuk distribusi publik yang aman, pindahkan signing request ke backend milik sendiri.
- Playback bergantung pada URL stream yang dikembalikan QuickPlay dan dukungan format stream tersebut. Jika provider menolak request dari aplikasi atau mengembalikan URL yang kedaluwarsa, provider perlu mengizinkan akses tersebut.
